"""
Tool Selection Agent — routes queries to the optimal structured tool.

Responsibilities:
  1. Analyse the query to determine which clinical tools are needed
  2. Dynamically select tools from the MCP server's available set
  3. Execute tool calls with fallback logic
  4. Write structured results back into AgentState

Design: this agent acts as a bridge between the LLM reasoning layer and
the MCP tool server.  It does NOT do retrieval — that's the RetrievalAgent's
job.  It handles structured lookups (drug interactions, ICD codes, guidelines).
"""

from __future__ import annotations

import json
import time
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage

from src.config.logging import get_logger
from src.models.schemas import (
    AgentState,
    DocumentChunk,
    SourceType,
    ToolCall,
    ToolSelectionResult,
)
from src.tools.clinical_api import ClinicalAPI
from src.tools.llm_factory import get_llm

logger = get_logger(__name__)

TOOL_SELECTION_PROMPT = """\
You are a clinical tool routing agent.  Given a healthcare query, decide which
tools to invoke and with what arguments.

Available tools:
{tool_descriptions}

Rules:
1. Select ONLY the tools needed for this specific query.
2. Provide the exact arguments each tool expects.
3. If no tools are relevant, return an empty list.
4. Return ONLY valid JSON — no markdown, no explanation.

Return format:
[
  {{"tool": "<tool_name>", "args": {{"<param>": "<value>"}}, "reason": "<why>"}}
]
"""

# Tool descriptions (mirrors MCP schema but formatted for the LLM)
TOOL_DESCRIPTIONS = """
1. lookup_drug_interactions(drug_name: str)
   — Look up drug-drug interactions, severity, and management for a medication.

2. search_icd_codes(query: str)
   — Search ICD-10 diagnosis codes by keyword or code prefix.

3. get_clinical_guideline(condition: str)
   — Retrieve evidence-based clinical guidelines for a condition.
"""


class ToolSelectionAgent:
    """Dynamically select and invoke clinical tools based on query analysis."""

    def __init__(self, clinical_api: ClinicalAPI | None = None) -> None:
        self._api = clinical_api or ClinicalAPI()
        self._llm = get_llm()

    async def run(self, state: AgentState) -> AgentState:
        """Analyse query, select tools, execute, and update state."""
        query = state["query"]
        logger.info("tool_selection_start", query=query[:100])

        # Step 1: Ask LLM which tools to use
        tool_plan = await self._select_tools(query)

        # Step 2: Execute each tool call
        calls: list[ToolCall] = []
        extra_chunks: list[DocumentChunk] = []

        for planned in tool_plan:
            tool_name = planned.get("tool", "")
            args = planned.get("args", {})
            reason = planned.get("reason", "")

            t0 = time.perf_counter()
            try:
                result, chunks = self._execute_tool(tool_name, args)
                elapsed = (time.perf_counter() - t0) * 1000
                calls.append(ToolCall(
                    tool_name=tool_name,
                    arguments=args,
                    result=result,
                    latency_ms=round(elapsed, 1),
                    success=True,
                ))
                extra_chunks.extend(chunks)
                logger.info("tool_executed", tool=tool_name, latency_ms=round(elapsed, 1))
            except Exception as exc:
                elapsed = (time.perf_counter() - t0) * 1000
                calls.append(ToolCall(
                    tool_name=tool_name,
                    arguments=args,
                    error=str(exc),
                    latency_ms=round(elapsed, 1),
                    success=False,
                ))
                logger.warning("tool_failed", tool=tool_name, error=str(exc))

        # Step 3: Merge tool-derived chunks into retrieval results
        self._merge_chunks(state, extra_chunks)

        # Step 4: Write tool selection results
        ts_result = ToolSelectionResult(
            calls=calls,
            reasoning=f"Selected {len(calls)} tools based on query analysis",
        )
        state["tool_selection_result"] = ts_result.model_dump(mode="json")
        state.setdefault("trace", []).append({
            "agent": "tool_selection",
            "tools_called": [c.tool_name for c in calls],
            "successes": sum(1 for c in calls if c.success),
        })

        return state

    async def _select_tools(self, query: str) -> list[dict[str, Any]]:
        """Use LLM to decide which tools to invoke."""
        messages = [
            SystemMessage(
                content=TOOL_SELECTION_PROMPT.format(tool_descriptions=TOOL_DESCRIPTIONS)
            ),
            HumanMessage(content=f"Query: {query}"),
        ]
        response = await self._llm.ainvoke(messages)
        raw = response.content.strip()

        # Strip markdown fences
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1]
        if raw.endswith("```"):
            raw = raw.rsplit("```", 1)[0]

        try:
            return json.loads(raw.strip())
        except json.JSONDecodeError:
            logger.warning("tool_selection_parse_failed", raw=raw[:200])
            return []

    def _execute_tool(
        self, tool_name: str, args: dict[str, Any]
    ) -> tuple[Any, list[DocumentChunk]]:
        """Execute a tool call and return (raw_result, document_chunks)."""
        dispatch = {
            "lookup_drug_interactions": self._run_drug_lookup,
            "search_icd_codes": self._run_icd_search,
            "get_clinical_guideline": self._run_guideline,
        }
        handler = dispatch.get(tool_name)
        if handler is None:
            raise ValueError(f"Unknown tool: {tool_name}")
        return handler(args)

    def _run_drug_lookup(self, args: dict[str, Any]) -> tuple[list, list[DocumentChunk]]:
        drug = args.get("drug_name", "")
        raw = self._api.lookup_drug_interactions(drug)
        chunks = self._api.interactions_to_chunks(drug)
        return raw, chunks

    def _run_icd_search(self, args: dict[str, Any]) -> tuple[list, list[DocumentChunk]]:
        query = args.get("query", "")
        raw = self._api.search_icd_codes(query)
        chunks = self._api.icd_to_chunks(query)
        return raw, chunks

    def _run_guideline(self, args: dict[str, Any]) -> tuple[list, list[DocumentChunk]]:
        condition = args.get("condition", "")
        raw = self._api.get_guideline(condition)
        chunks = self._api.guideline_to_chunks(condition)
        return raw, chunks

    @staticmethod
    def _merge_chunks(state: AgentState, new_chunks: list[DocumentChunk]) -> None:
        """Merge tool-derived chunks into the retrieval result in state."""
        if not new_chunks:
            return

        retrieval = state.get("retrieval_result", {"chunks": [], "query_used": "", "strategy": "hybrid"})
        existing = retrieval.get("chunks", [])
        existing_ids = {c.get("chunk_id", "") for c in existing}

        for chunk in new_chunks:
            dump = chunk.model_dump(mode="json")
            if dump.get("chunk_id") not in existing_ids:
                existing.append(dump)
                existing_ids.add(dump.get("chunk_id", ""))

        retrieval["chunks"] = existing
        state["retrieval_result"] = retrieval
