"""
Retrieval Agent — performs hybrid search and cross-encoder reranking.

Responsibilities:
  1. Receive the query (or a sub-query from the plan)
  2. Run hybrid retrieval (vector + BM25 via Reciprocal Rank Fusion)
  3. Rerank candidates with a cross-encoder
  4. Write top-K chunks back into AgentState

Design: this agent has exclusive ownership of the VectorStore tool.
Other agents access retrieved chunks only through the shared state.
"""

from __future__ import annotations

import time

from langchain_core.messages import HumanMessage, SystemMessage

from src.config import get_settings
from src.config.logging import get_logger
from src.models.schemas import AgentState, RetrievalResult
from src.tools.llm_factory import get_llm
from src.tools.vector_store import VectorStore

logger = get_logger(__name__)

QUERY_EXPANSION_PROMPT = """\
You are a clinical search query optimizer.  Given the user's original query,
generate 2-3 alternative search queries that would help retrieve relevant
clinical documents.  Focus on medical terminology, synonyms, and related concepts.

Return ONLY the queries, one per line.  No numbering, no explanation.
"""


class RetrievalAgent:
    """Hybrid retrieval with optional query expansion and reranking."""

    def __init__(self, vector_store: VectorStore | None = None) -> None:
        self._store = vector_store or VectorStore()
        self._llm = get_llm()
        self._settings = get_settings()

    async def run(self, state: AgentState) -> AgentState:
        """Execute retrieval and write results into state."""
        query = state["query"]
        logger.info("retrieval_start", query=query[:100])
        t0 = time.perf_counter()

        # Step 1: Query expansion
        expanded_queries = await self._expand_query(query)
        all_queries = [query] + expanded_queries

        # Step 2: Hybrid search across all query variants
        all_chunks = []
        seen_ids: set[str] = set()
        for q in all_queries:
            chunks = self._store.hybrid_search(q)
            for c in chunks:
                if c.chunk_id not in seen_ids:
                    seen_ids.add(c.chunk_id)
                    all_chunks.append(c)

        # Step 3: Cross-encoder reranking against the original query
        reranked = self._store.rerank(query, all_chunks)

        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.info(
            "retrieval_complete",
            candidates=len(all_chunks),
            reranked=len(reranked),
            latency_ms=round(elapsed_ms, 1),
        )

        result = RetrievalResult(
            chunks=reranked,
            query_used=query,
            strategy="hybrid",
        )

        state["retrieval_result"] = result.model_dump(mode="json")
        state.setdefault("trace", []).append({
            "agent": "retrieval",
            "candidates": len(all_chunks),
            "reranked": len(reranked),
            "latency_ms": round(elapsed_ms, 1),
        })

        return state

    async def _expand_query(self, query: str) -> list[str]:
        """Use the LLM to generate alternative search queries."""
        try:
            messages = [
                SystemMessage(content=QUERY_EXPANSION_PROMPT),
                HumanMessage(content=query),
            ]
            response = await self._llm.ainvoke(messages)
            lines = [
                line.strip()
                for line in response.content.strip().split("\n")
                if line.strip()
            ]
            logger.info("query_expansion", original=query[:80], variants=len(lines))
            return lines[:3]
        except Exception as exc:
            logger.warning("query_expansion_failed", error=str(exc))
            return []
