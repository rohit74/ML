"""
Synthesis Agent — fuses evidence from multiple sources into a grounded answer.

Responsibilities:
  1. Receive retrieved chunks + tool outputs from AgentState
  2. Generate a comprehensive clinical answer with inline citations
  3. Ground every claim to a specific source chunk
  4. Output structured SynthesisResult with answer + citations + confidence

Design: the synthesis agent is the ONLY agent that generates the user-facing
answer.  The orchestrator plans, retrieval gathers, tools provide data,
validation checks — but synthesis writes.
"""

from __future__ import annotations

from langchain_core.messages import HumanMessage, SystemMessage

from src.config.logging import get_logger
from src.models.schemas import (
    AgentState,
    Citation,
    DocumentChunk,
    SourceType,
    SynthesisResult,
)
from src.tools.llm_factory import get_llm

logger = get_logger(__name__)

SYNTHESIS_SYSTEM_PROMPT = """\
You are a clinical synthesis agent.  Your job is to produce a comprehensive,
evidence-based answer to a healthcare query using ONLY the provided source
documents.

Rules:
1. Base your answer EXCLUSIVELY on the evidence provided below.
2. For every factual claim, include a citation in the format [Source N] where
   N corresponds to the source index.
3. If the evidence is insufficient to answer confidently, say so explicitly.
4. Use precise medical terminology.  Avoid speculation.
5. Structure the answer with clear paragraphs.  Start with a direct answer,
   then supporting details.
6. At the end, provide a confidence score from 0.0 to 1.0 reflecting how
   well the sources support your answer.

Source Documents:
{sources}

Respond in the following format:
ANSWER:
<your answer with [Source N] citations>

CONFIDENCE: <float 0.0-1.0>
"""


class SynthesisAgent:
    """Generate cited, evidence-grounded clinical answers."""

    def __init__(self) -> None:
        self._llm = get_llm()

    async def run(self, state: AgentState) -> AgentState:
        """Synthesise answer from all gathered evidence."""
        query = state["query"]
        chunks = self._extract_chunks(state)

        logger.info("synthesis_start", query=query[:100], sources=len(chunks))

        if not chunks:
            result = SynthesisResult(
                answer="I could not find sufficient evidence in the knowledge base to answer this query. "
                       "Please refine your question or ensure relevant documents have been ingested.",
                citations=[],
                confidence=0.0,
            )
            state["synthesis_result"] = result.model_dump(mode="json")
            return state

        # Build source context for the LLM
        source_text = self._format_sources(chunks)

        messages = [
            SystemMessage(content=SYNTHESIS_SYSTEM_PROMPT.format(sources=source_text)),
            HumanMessage(content=f"Query: {query}"),
        ]

        response = await self._llm.ainvoke(messages)
        raw = response.content.strip()

        # Parse structured response
        answer, confidence = self._parse_response(raw)
        citations = self._extract_citations(answer, chunks)

        result = SynthesisResult(
            answer=answer,
            citations=citations,
            confidence=confidence,
        )

        state["synthesis_result"] = result.model_dump(mode="json")
        state.setdefault("trace", []).append({
            "agent": "synthesis",
            "sources_used": len(chunks),
            "citations": len(citations),
            "confidence": confidence,
        })

        logger.info("synthesis_complete", confidence=confidence, citations=len(citations))
        return state

    # ── Helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _extract_chunks(state: AgentState) -> list[DocumentChunk]:
        """Pull chunks from retrieval result in state."""
        retrieval = state.get("retrieval_result", {})
        raw_chunks = retrieval.get("chunks", [])
        chunks: list[DocumentChunk] = []
        for rc in raw_chunks:
            try:
                chunks.append(DocumentChunk(**rc))
            except Exception:
                continue
        return chunks

    @staticmethod
    def _format_sources(chunks: list[DocumentChunk]) -> str:
        """Format chunks into numbered source blocks for the LLM."""
        parts: list[str] = []
        for i, chunk in enumerate(chunks):
            header = f"[Source {i}] ({chunk.source_type.value})"
            meta_str = ""
            if chunk.metadata:
                meta_items = [f"{k}={v}" for k, v in chunk.metadata.items() if v]
                if meta_items:
                    meta_str = f" | Metadata: {', '.join(meta_items[:5])}"
            parts.append(f"{header}{meta_str}\n{chunk.content}\n")
        return "\n---\n".join(parts)

    @staticmethod
    def _parse_response(raw: str) -> tuple[str, float]:
        """Extract answer text and confidence from LLM response."""
        answer = raw
        confidence = 0.5  # default

        if "CONFIDENCE:" in raw:
            parts = raw.rsplit("CONFIDENCE:", 1)
            answer = parts[0].strip()
            try:
                conf_str = parts[1].strip().split()[0]
                confidence = float(conf_str)
                confidence = max(0.0, min(1.0, confidence))
            except (ValueError, IndexError):
                pass

        # Strip the ANSWER: prefix if present
        if answer.startswith("ANSWER:"):
            answer = answer[len("ANSWER:"):].strip()

        return answer, confidence

    @staticmethod
    def _extract_citations(answer: str, chunks: list[DocumentChunk]) -> list[Citation]:
        """Parse [Source N] references from the answer and build Citation objects."""
        import re

        citations: list[Citation] = []
        seen: set[int] = set()

        for match in re.finditer(r"\[Source\s+(\d+)\]", answer):
            idx = int(match.group(1))
            if idx in seen or idx >= len(chunks):
                continue
            seen.add(idx)

            chunk = chunks[idx]
            excerpt = chunk.content[:200] + ("..." if len(chunk.content) > 200 else "")
            citations.append(
                Citation(
                    chunk_id=chunk.chunk_id,
                    source_type=chunk.source_type,
                    excerpt=excerpt,
                    relevance=chunk.score,
                )
            )

        return citations
