"""
Orchestrator Agent — the central planner in the multi-agent graph.

Responsibilities:
  1. Decompose the user's high-level clinical query into an execution plan
  2. Decide which agents to delegate to and in what order
  3. Evaluate intermediate outputs and re-plan if results are insufficient
  4. Maintain the AgentState through the LangGraph workflow

Design principle: the orchestrator NEVER answers the query itself.  It only
plans, delegates, and evaluates — all domain reasoning is handled by the
specialised agents.
"""

from __future__ import annotations

import json
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.output_parsers import StrOutputParser

from src.config import get_settings
from src.config.logging import get_logger
from src.models.schemas import (
    AgentRole,
    AgentState,
    ExecutionPlan,
    PlanStep,
    PlanStepStatus,
)
from src.tools.llm_factory import get_llm

logger = get_logger(__name__)

# ── System prompt ────────────────────────────────────────────────────

PLANNER_SYSTEM_PROMPT = """\
You are a clinical query planner.  Given a user's healthcare question, you must
decompose it into an ordered execution plan.  Each step delegates to exactly
ONE specialised agent:

Available agents:
- retrieval: search the knowledge base for relevant clinical notes, guidelines, or references.
- tool_selection: use structured tools (drug interaction lookup, ICD-10 search, clinical guidelines) via MCP when the query needs specific factual data.
- synthesis: fuse evidence from multiple sources into a grounded, cited answer.
- validation: fact-check the synthesised answer against source documents to detect hallucinations.

Rules:
1. ALWAYS include a retrieval step first if the query needs knowledge-base context.
2. Include tool_selection when the query involves drug names, ICD codes, or guideline lookups.
3. ALWAYS include synthesis after evidence gathering.
4. ALWAYS include validation as the final step.
5. Return ONLY valid JSON — no markdown fences, no explanation.

Return a JSON array of steps:
[
  {"agent": "<agent_name>", "description": "<what this step should accomplish>"}
]
"""

REPLAN_SYSTEM_PROMPT = """\
You are a clinical query planner performing re-planning.

The previous plan's validation step found issues:
{validation_feedback}

Original query: {query}

Generate a revised execution plan that addresses the shortcomings.
Focus on retrieving additional evidence or using different tools.
Return ONLY a JSON array of steps — same format as before.
"""


class OrchestratorAgent:
    """Plans, delegates, and re-plans the agentic workflow."""

    def __init__(self) -> None:
        self._llm = get_llm()
        self._settings = get_settings()
        self._parser = StrOutputParser()

    # ── Plan generation ──────────────────────────────────────────────

    async def plan(self, state: AgentState) -> AgentState:
        """Generate an execution plan from the user query."""
        query = state["query"]
        logger.info("orchestrator_planning", query=query[:100])

        messages = [
            SystemMessage(content=PLANNER_SYSTEM_PROMPT),
            HumanMessage(content=f"Query: {query}"),
        ]
        response = await self._llm.ainvoke(messages)
        raw = self._parser.invoke(response)

        steps = self._parse_plan_steps(raw)
        plan = ExecutionPlan(query=query, steps=steps)

        state["plan"] = plan.model_dump(mode="json")
        state["current_step_index"] = 0
        state["replan_count"] = 0
        state["needs_replan"] = False
        state["trace"] = state.get("trace", [])
        state["trace"].append({
            "agent": "orchestrator",
            "action": "plan",
            "steps": len(steps),
        })

        logger.info("plan_created", steps=len(steps))
        return state

    async def replan(self, state: AgentState) -> AgentState:
        """Generate a revised plan after validation failure."""
        replan_count = state.get("replan_count", 0) + 1
        max_retries = self._settings.max_replan_attempts

        if replan_count > max_retries:
            logger.warning("max_replans_reached", count=replan_count)
            state["needs_replan"] = False
            return state

        validation = state.get("validation_verdict", {})
        feedback = validation.get("reasoning", "No details available")

        messages = [
            SystemMessage(
                content=REPLAN_SYSTEM_PROMPT.format(
                    validation_feedback=feedback,
                    query=state["query"],
                )
            ),
            HumanMessage(content="Generate a revised plan."),
        ]
        response = await self._llm.ainvoke(messages)
        raw = self._parser.invoke(response)

        steps = self._parse_plan_steps(raw)
        plan = ExecutionPlan(
            query=state["query"],
            steps=steps,
            replan_count=replan_count,
        )

        state["plan"] = plan.model_dump(mode="json")
        state["current_step_index"] = 0
        state["replan_count"] = replan_count
        state["needs_replan"] = False
        state["trace"].append({
            "agent": "orchestrator",
            "action": "replan",
            "attempt": replan_count,
            "steps": len(steps),
        })

        logger.info("replan_created", attempt=replan_count, steps=len(steps))
        return state

    # ── Step evaluation ──────────────────────────────────────────────

    def get_current_step(self, state: AgentState) -> PlanStep | None:
        """Return the next pending step, or None if plan is complete."""
        plan_data = state.get("plan", {})
        steps = plan_data.get("steps", [])
        idx = state.get("current_step_index", 0)

        if idx >= len(steps):
            return None
        return PlanStep(**steps[idx])

    def advance_step(self, state: AgentState) -> AgentState:
        """Mark the current step complete and advance the index."""
        plan_data = state.get("plan", {})
        steps = plan_data.get("steps", [])
        idx = state.get("current_step_index", 0)

        if idx < len(steps):
            steps[idx]["status"] = PlanStepStatus.COMPLETED.value
            plan_data["steps"] = steps
            state["plan"] = plan_data
            state["current_step_index"] = idx + 1

        return state

    def mark_step_failed(self, state: AgentState, error: str) -> AgentState:
        """Mark the current step as failed with an error message."""
        plan_data = state.get("plan", {})
        steps = plan_data.get("steps", [])
        idx = state.get("current_step_index", 0)

        if idx < len(steps):
            steps[idx]["status"] = PlanStepStatus.FAILED.value
            steps[idx]["error"] = error
            plan_data["steps"] = steps
            state["plan"] = plan_data
            state["current_step_index"] = idx + 1

        return state

    # ── Helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _parse_plan_steps(raw: str) -> list[PlanStep]:
        """Parse LLM output into PlanStep objects, with fallback."""
        # Strip markdown fences if present
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[-1]
        if cleaned.endswith("```"):
            cleaned = cleaned.rsplit("```", 1)[0]
        cleaned = cleaned.strip()

        try:
            items: list[dict[str, Any]] = json.loads(cleaned)
        except json.JSONDecodeError:
            logger.warning("plan_parse_fallback", raw=raw[:200])
            # Fallback: minimal plan
            items = [
                {"agent": "retrieval", "description": "Search knowledge base"},
                {"agent": "synthesis", "description": "Generate answer"},
                {"agent": "validation", "description": "Validate answer"},
            ]

        steps: list[PlanStep] = []
        for item in items:
            agent_str = item.get("agent", "retrieval")
            try:
                agent = AgentRole(agent_str)
            except ValueError:
                agent = AgentRole.RETRIEVAL
            steps.append(
                PlanStep(
                    agent=agent,
                    description=item.get("description", ""),
                )
            )

        # Ensure synthesis and validation are always present
        agent_names = {s.agent for s in steps}
        if AgentRole.SYNTHESIS not in agent_names:
            steps.append(PlanStep(agent=AgentRole.SYNTHESIS, description="Synthesise answer from evidence"))
        if AgentRole.VALIDATION not in agent_names:
            steps.append(PlanStep(agent=AgentRole.VALIDATION, description="Validate answer faithfulness"))

        return steps
