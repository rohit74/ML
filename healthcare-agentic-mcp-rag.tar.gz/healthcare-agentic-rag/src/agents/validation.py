"""
Validation Agent — fact-checks the synthesised answer against sources.

Responsibilities:
  1. Compare every claim in the synthesis answer to source documents
  2. Score overall faithfulness (0.0 – 1.0)
  3. Flag specific claims that are unsupported or contradicted
  4. Decide whether the answer passes or needs re-planning

Design: the validation agent is the quality gate.  If faithfulness falls
below the configured threshold, it sets ``needs_replan = True`` so the
orchestrator can generate a revised execution plan.
"""

from __future__ import annotations

import json

from langchain_core.messages import HumanMessage, SystemMessage

from src.config import get_settings
from src.config.logging import get_logger
from src.models.schemas import (
    AgentState,
    DocumentChunk,
    ValidationVerdict,
)
from src.tools.llm_factory import get_llm

logger = get_logger(__name__)

VALIDATION_SYSTEM_PROMPT = """\
You are a clinical answer validation agent.  Your task is to fact-check an
AI-generated answer against the source documents it was derived from.

For each claim in the answer:
  - Check whether it is SUPPORTED by at least one source document.
  - Check whether it CONTRADICTS any source document.
  - Check whether it is FABRICATED (not grounded in any source).

Source Documents:
{sources}

Answer to validate:
{answer}

Respond ONLY with valid JSON (no markdown fences):
{{
  "is_faithful": true/false,
  "faithfulness_score": <float 0.0-1.0>,
  "flagged_claims": ["<unsupported claim 1>", ...],
  "reasoning": "<brief explanation of your assessment>"
}}
"""


class ValidationAgent:
    """Validate synthesised answers for faithfulness to source evidence."""

    def __init__(self) -> None:
        self._llm = get_llm()
        self._settings = get_settings()

    async def run(self, state: AgentState) -> AgentState:
        """Validate the synthesis result and update state."""
        synthesis = state.get("synthesis_result", {})
        answer = synthesis.get("answer", "")

        if not answer:
            verdict = ValidationVerdict(
                is_faithful=False,
                faithfulness_score=0.0,
                reasoning="No answer was generated to validate.",
            )
            state["validation_verdict"] = verdict.model_dump(mode="json")
            state["needs_replan"] = True
            return state

        chunks = self._extract_chunks(state)
        logger.info("validation_start", answer_len=len(answer), sources=len(chunks))

        if not chunks:
            # No sources — cannot validate, flag for replan
            verdict = ValidationVerdict(
                is_faithful=False,
                faithfulness_score=0.0,
                reasoning="No source documents available for validation.",
            )
            state["validation_verdict"] = verdict.model_dump(mode="json")
            state["needs_replan"] = True
            return state

        # Build source context
        source_text = self._format_sources(chunks)

        messages = [
            SystemMessage(
                content=VALIDATION_SYSTEM_PROMPT.format(
                    sources=source_text,
                    answer=answer,
                )
            ),
            HumanMessage(content="Validate the answer above."),
        ]

        response = await self._llm.ainvoke(messages)
        raw = response.content.strip()
        verdict = self._parse_verdict(raw)

        # Decision: does this pass or need re-planning?
        threshold = self._settings.hallucination_threshold
        needs_replan = verdict.faithfulness_score < threshold

        state["validation_verdict"] = verdict.model_dump(mode="json")
        state["needs_replan"] = needs_replan

        if needs_replan:
            logger.warning(
                "validation_failed",
                score=verdict.faithfulness_score,
                threshold=threshold,
                flagged=len(verdict.flagged_claims),
            )
        else:
            logger.info(
                "validation_passed",
                score=verdict.faithfulness_score,
                flagged=len(verdict.flagged_claims),
            )

        # Build final answer
        if not needs_replan:
            state["final_answer"] = answer

        state.setdefault("trace", []).append({
            "agent": "validation",
            "faithfulness_score": verdict.faithfulness_score,
            "is_faithful": verdict.is_faithful,
            "flagged_claims": len(verdict.flagged_claims),
            "needs_replan": needs_replan,
        })

        return state

    # ── Helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _extract_chunks(state: AgentState) -> list[DocumentChunk]:
        """Pull chunks from retrieval result."""
        retrieval = state.get("retrieval_result", {})
        raw_chunks = retrieval.get("chunks", [])
        chunks: list[DocumentChunk] = []
        for rc in raw_chunks:
            try:
                chunks.append(DocumentChunk(**rc))
            except Exception:
                continue
        return chunks

    @staticmethod
    def _format_sources(chunks: list[DocumentChunk]) -> str:
        """Build numbered source list."""
        parts = []
        for i, chunk in enumerate(chunks):
            parts.append(f"[Source {i}] ({chunk.source_type.value})\n{chunk.content}")
        return "\n---\n".join(parts)

    @staticmethod
    def _parse_verdict(raw: str) -> ValidationVerdict:
        """Parse the LLM's JSON validation output."""
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[-1]
        if cleaned.endswith("```"):
            cleaned = cleaned.rsplit("```", 1)[0]
        cleaned = cleaned.strip()

        try:
            data = json.loads(cleaned)
            return ValidationVerdict(
                is_faithful=data.get("is_faithful", False),
                faithfulness_score=float(data.get("faithfulness_score", 0.5)),
                flagged_claims=data.get("flagged_claims", []),
                reasoning=data.get("reasoning", ""),
            )
        except (json.JSONDecodeError, ValueError) as exc:
            logger.warning("validation_parse_fallback", error=str(exc), raw=raw[:200])
            return ValidationVerdict(
                is_faithful=True,
                faithfulness_score=0.6,
                reasoning=f"Could not parse validation output; defaulting to marginal pass. Raw: {raw[:200]}",
            )
