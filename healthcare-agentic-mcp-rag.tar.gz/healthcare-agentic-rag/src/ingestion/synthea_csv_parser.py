"""
Synthea CSV export parser.

Reads the standard Synthea CSV exports (patients.csv, conditions.csv,
medications.csv, encounters.csv, observations.csv, careplans.csv,
procedures.csv) and produces linked DocumentChunks for the RAG pipeline.

The parser joins data across tables using PATIENT and ENCOUNTER foreign
keys — this is the same linking model Synthea uses, making the output
compatible with real Synthea data drops.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any

from src.config.logging import get_logger
from src.models.schemas import DocumentChunk, SourceType

logger = get_logger(__name__)


class SyntheaCSVParser:
    """Parse Synthea CSV exports into DocumentChunks."""

    def __init__(self) -> None:
        self._patients: dict[str, dict] = {}
        self._conditions: dict[str, list[dict]] = {}      # patient_id → [conditions]
        self._medications: dict[str, list[dict]] = {}      # patient_id → [medications]
        self._encounters: dict[str, list[dict]] = {}       # patient_id → [encounters]
        self._observations: dict[str, list[dict]] = {}     # patient_id → [observations]
        self._careplans: dict[str, list[dict]] = {}        # patient_id → [careplans]
        self._procedures: dict[str, list[dict]] = {}       # patient_id → [procedures]

    def parse_directory(self, directory: Path) -> list[DocumentChunk]:
        """
        Parse all Synthea CSV files in a directory.

        Expected files:
            patients.csv, conditions.csv, medications.csv,
            encounters.csv, observations.csv, careplans.csv,
            procedures.csv
        """
        if not directory.exists():
            logger.warning("synthea_csv_dir_missing", path=str(directory))
            return []

        # Load all tables
        self._load_table(directory / "patients.csv", self._index_patient)
        self._load_table(directory / "conditions.csv", self._index_by_patient, self._conditions)
        self._load_table(directory / "medications.csv", self._index_by_patient, self._medications)
        self._load_table(directory / "encounters.csv", self._index_by_patient, self._encounters)
        self._load_table(directory / "observations.csv", self._index_by_patient, self._observations)
        self._load_table(directory / "careplans.csv", self._index_by_patient, self._careplans)
        self._load_table(directory / "procedures.csv", self._index_by_patient, self._procedures)

        logger.info(
            "synthea_csv_loaded",
            patients=len(self._patients),
            conditions=sum(len(v) for v in self._conditions.values()),
            medications=sum(len(v) for v in self._medications.values()),
            encounters=sum(len(v) for v in self._encounters.values()),
            observations=sum(len(v) for v in self._observations.values()),
            careplans=sum(len(v) for v in self._careplans.values()),
        )

        # Build chunks per patient
        chunks: list[DocumentChunk] = []
        for patient_id, patient in self._patients.items():
            chunks.extend(self._build_patient_chunks(patient_id, patient))

        logger.info("synthea_csv_chunks", total=len(chunks))
        return chunks

    def _build_patient_chunks(self, pid: str, patient: dict) -> list[DocumentChunk]:
        """Build all chunks for a single patient."""
        chunks: list[DocumentChunk] = []
        name = f"{patient.get('FIRST', '')} {patient.get('LAST', '')}".strip()
        meta = {
            "patient_id": pid,
            "patient_name": name,
            "gender": patient.get("GENDER", ""),
            "birth_date": patient.get("BIRTHDATE", ""),
            "source_format": "synthea_csv",
        }

        # Patient summary
        chunks.append(self._patient_summary_chunk(pid, patient, meta))

        # Conditions
        for cond in self._conditions.get(pid, []):
            chunks.append(self._condition_chunk(cond, meta))

        # Medication summary
        meds = self._medications.get(pid, [])
        if meds:
            chunks.append(self._medication_summary_chunk(meds, meta))

        # Encounters with linked observations
        for enc in self._encounters.get(pid, []):
            enc_id = enc.get("Id", "")
            linked_obs = [o for o in self._observations.get(pid, [])
                          if o.get("ENCOUNTER") == enc_id]
            chunks.append(self._encounter_chunk(enc, linked_obs, meta))

        # Care plans
        for cp in self._careplans.get(pid, []):
            chunks.append(self._careplan_chunk(cp, meta))

        # Procedures
        for proc in self._procedures.get(pid, []):
            chunks.append(self._procedure_chunk(proc, meta))

        return chunks

    # ── Chunk builders ───────────────────────────────────────────────

    def _patient_summary_chunk(self, pid: str, patient: dict, meta: dict) -> DocumentChunk:
        conditions = self._conditions.get(pid, [])
        meds = self._medications.get(pid, [])
        active_meds = [m for m in meds if not m.get("STOP")]
        careplans = self._careplans.get(pid, [])
        encounters = self._encounters.get(pid, [])

        cond_list = "\n".join(f"  - {c['DESCRIPTION']} (onset: {c.get('START', 'unknown')})"
                              for c in conditions) or "  None documented"
        med_list = "\n".join(f"  - {m['DESCRIPTION']}" for m in active_meds) or "  None"
        cp_list = ", ".join(c.get("DESCRIPTION", "") for c in careplans) or "None"

        text = f"""PATIENT SUMMARY (Synthea Record)
Name: {meta['patient_name']}
Gender: {patient.get('GENDER', '')}
DOB: {patient.get('BIRTHDATE', '')}
Race: {patient.get('RACE', '')} | Ethnicity: {patient.get('ETHNICITY', '')}
Location: {patient.get('CITY', '')}, {patient.get('STATE', '')} {patient.get('ZIP', '')}
{'Deceased: ' + patient['DEATHDATE'] if patient.get('DEATHDATE') else 'Status: Alive'}

ACTIVE CONDITIONS:
{cond_list}

ACTIVE MEDICATIONS ({len(active_meds)}):
{med_list}

ENCOUNTER HISTORY: {len(encounters)} visits
ACTIVE CARE PLANS: {cp_list}"""

        return DocumentChunk(
            content=text.strip(),
            source_type=SourceType.CLINICAL_NOTE,
            metadata={**meta, "chunk_type": "patient_summary"},
        )

    @staticmethod
    def _condition_chunk(cond: dict, meta: dict) -> DocumentChunk:
        status = "Active" if not cond.get("STOP") else f"Resolved ({cond['STOP']})"
        text = (
            f"DIAGNOSIS — Patient: {meta['patient_name']}\n"
            f"Condition: {cond.get('DESCRIPTION', 'Unknown')}\n"
            f"SNOMED Code: {cond.get('CODE', '')}\n"
            f"Onset: {cond.get('START', 'unknown')}\n"
            f"Status: {status}"
        )
        return DocumentChunk(
            content=text,
            source_type=SourceType.CLINICAL_NOTE,
            metadata={**meta, "chunk_type": "condition",
                      "condition_code": cond.get("CODE", ""),
                      "condition_display": cond.get("DESCRIPTION", "")},
        )

    @staticmethod
    def _medication_summary_chunk(meds: list[dict], meta: dict) -> DocumentChunk:
        active = [m for m in meds if not m.get("STOP")]
        stopped = [m for m in meds if m.get("STOP")]

        lines = [f"MEDICATION LIST — Patient: {meta['patient_name']}\n"]
        if active:
            lines.append("ACTIVE MEDICATIONS:")
            for m in active:
                reason = f" (for: {m['REASONDESCRIPTION']})" if m.get("REASONDESCRIPTION") else ""
                lines.append(f"  - {m['DESCRIPTION']}{reason} — started {m.get('START', '')}")
        if stopped:
            lines.append("\nDISCONTINUED:")
            for m in stopped[:10]:
                lines.append(f"  - {m['DESCRIPTION']} (stopped: {m.get('STOP', '')})")

        return DocumentChunk(
            content="\n".join(lines),
            source_type=SourceType.CLINICAL_NOTE,
            metadata={**meta, "chunk_type": "medication_list",
                      "active_count": len(active)},
        )

    @staticmethod
    def _encounter_chunk(enc: dict, observations: list[dict], meta: dict) -> DocumentChunk:
        obs_text = ""
        if observations:
            obs_text = "\nObservations:\n" + "\n".join(
                f"  {o.get('DESCRIPTION', '')}: {o.get('VALUE', '')} {o.get('UNITS', '')}"
                for o in observations
            )

        reason = f"\nReason: {enc['REASONDESCRIPTION']}" if enc.get("REASONDESCRIPTION") else ""

        text = (
            f"ENCOUNTER — Patient: {meta['patient_name']}\n"
            f"Type: {enc.get('DESCRIPTION', 'Unknown')}\n"
            f"Class: {enc.get('ENCOUNTERCLASS', '')}\n"
            f"Date: {enc.get('START', '')[:10]}"
            f"{reason}"
            f"{obs_text}"
        )
        return DocumentChunk(
            content=text,
            source_type=SourceType.CLINICAL_NOTE,
            metadata={**meta, "chunk_type": "encounter",
                      "encounter_class": enc.get("ENCOUNTERCLASS", ""),
                      "encounter_date": enc.get("START", "")[:10]},
        )

    @staticmethod
    def _careplan_chunk(cp: dict, meta: dict) -> DocumentChunk:
        text = (
            f"CARE PLAN — Patient: {meta['patient_name']}\n"
            f"Plan: {cp.get('DESCRIPTION', 'Unknown')}\n"
            f"Start: {cp.get('START', 'unknown')}\n"
            f"Status: {'Active' if not cp.get('STOP') else 'Completed'}\n"
            f"Reason: {cp.get('REASONDESCRIPTION', 'Not specified')}"
        )
        return DocumentChunk(
            content=text,
            source_type=SourceType.CLINICAL_NOTE,
            metadata={**meta, "chunk_type": "careplan",
                      "careplan_display": cp.get("DESCRIPTION", "")},
        )

    @staticmethod
    def _procedure_chunk(proc: dict, meta: dict) -> DocumentChunk:
        text = (
            f"PROCEDURE — Patient: {meta['patient_name']}\n"
            f"Procedure: {proc.get('DESCRIPTION', 'Unknown')}\n"
            f"Code: {proc.get('CODE', '')}\n"
            f"Date: {proc.get('DATE', 'unknown')}"
        )
        return DocumentChunk(
            content=text,
            source_type=SourceType.CLINICAL_NOTE,
            metadata={**meta, "chunk_type": "procedure"},
        )

    # ── CSV loading helpers ──────────────────────────────────────────

    def _load_table(self, path: Path, indexer, target=None) -> None:
        if not path.exists():
            logger.debug("csv_not_found", path=str(path))
            return
        with path.open(newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if target is not None:
                    indexer(row, target)
                else:
                    indexer(row)

    def _index_patient(self, row: dict) -> None:
        pid = row.get("Id", "")
        if pid:
            self._patients[pid] = row

    @staticmethod
    def _index_by_patient(row: dict, target: dict[str, list]) -> None:
        pid = row.get("PATIENT", "")
        if pid:
            target.setdefault(pid, []).append(row)
