"""
Synthea FHIR R4 Bundle parser.

Parses Synthea-generated FHIR Bundle JSON files and extracts linked
clinical data across all resource types:

  Patient → Encounter → Condition, MedicationRequest, Observation,
  CarePlan, Procedure, DiagnosticReport, etc.

The parser resolves internal references (urn:uuid:...) to build a
fully-linked patient record, then produces DocumentChunks optimised
for the RAG retrieval pipeline.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from src.config.logging import get_logger
from src.models.schemas import DocumentChunk, SourceType

logger = get_logger(__name__)

# Resource types we extract from Synthea bundles
SUPPORTED_RESOURCES = {
    "Patient", "Condition", "MedicationRequest", "Encounter",
    "Observation", "CarePlan", "Procedure", "DiagnosticReport",
    "AllergyIntolerance", "Immunization", "Claim",
}


class FHIRBundleParser:
    """Parse FHIR R4 Bundles (Synthea format) into DocumentChunks."""

    def parse_directory(self, directory: Path) -> list[DocumentChunk]:
        """Parse all .json FHIR bundles in a directory."""
        chunks: list[DocumentChunk] = []
        if not directory.exists():
            logger.warning("fhir_dir_not_found", path=str(directory))
            return chunks

        json_files = sorted(directory.glob("*.json"))
        for path in json_files:
            try:
                bundle_chunks = self.parse_bundle(path)
                chunks.extend(bundle_chunks)
            except Exception as exc:
                logger.warning("fhir_parse_error", file=path.name, error=str(exc))

        logger.info("fhir_parsed", files=len(json_files), chunks=len(chunks))
        return chunks

    def parse_bundle(self, path: Path) -> list[DocumentChunk]:
        """Parse a single FHIR Bundle JSON file."""
        with path.open() as f:
            bundle = json.load(f)

        if bundle.get("resourceType") != "Bundle":
            return []

        entries = bundle.get("entry", [])
        resources: dict[str, dict] = {}  # fullUrl → resource

        # Index all resources by fullUrl
        for entry in entries:
            full_url = entry.get("fullUrl", "")
            resource = entry.get("resource", {})
            if resource.get("resourceType") in SUPPORTED_RESOURCES:
                resources[full_url] = resource

        # Find Patient resource
        patient = None
        for res in resources.values():
            if res.get("resourceType") == "Patient":
                patient = res
                break

        if patient is None:
            return []

        patient_ref = f"urn:uuid:{patient['id']}"
        patient_name = self._extract_patient_name(patient)
        patient_meta = {
            "patient_id": patient["id"],
            "patient_name": patient_name,
            "gender": patient.get("gender", ""),
            "birth_date": patient.get("birthDate", ""),
        }

        chunks: list[DocumentChunk] = []

        # ── Patient summary chunk ────────────────────────────────────
        chunks.append(self._build_patient_summary(patient, resources, patient_meta))

        # ── Condition chunks ─────────────────────────────────────────
        for res in resources.values():
            if res.get("resourceType") == "Condition":
                chunk = self._build_condition_chunk(res, patient_meta)
                if chunk:
                    chunks.append(chunk)

        # ── Medication chunks ────────────────────────────────────────
        med_resources = [r for r in resources.values() if r.get("resourceType") == "MedicationRequest"]
        if med_resources:
            chunks.append(self._build_medication_summary(med_resources, patient_meta))

        # ── Encounter chunks ─────────────────────────────────────────
        for res in resources.values():
            if res.get("resourceType") == "Encounter":
                chunk = self._build_encounter_chunk(res, patient_meta)
                if chunk:
                    chunks.append(chunk)

        # ── Observation chunks (grouped by encounter date) ───────────
        obs_by_date: dict[str, list[dict]] = {}
        for res in resources.values():
            if res.get("resourceType") == "Observation":
                dt = res.get("effectiveDateTime", "")[:10]
                obs_by_date.setdefault(dt, []).append(res)

        for dt, obs_list in obs_by_date.items():
            chunk = self._build_observation_chunk(obs_list, dt, patient_meta)
            if chunk:
                chunks.append(chunk)

        # ── CarePlan chunks ──────────────────────────────────────────
        for res in resources.values():
            if res.get("resourceType") == "CarePlan":
                chunk = self._build_careplan_chunk(res, patient_meta)
                if chunk:
                    chunks.append(chunk)

        return chunks

    # ── Resource → Text converters ───────────────────────────────────

    def _build_patient_summary(
        self, patient: dict, resources: dict[str, dict], meta: dict
    ) -> DocumentChunk:
        """Build a comprehensive patient summary chunk."""
        name = meta["patient_name"]
        gender = patient.get("gender", "unknown")
        birth = patient.get("birthDate", "unknown")
        deceased = patient.get("deceasedDateTime", "")

        conditions = [r for r in resources.values() if r.get("resourceType") == "Condition"]
        meds = [r for r in resources.values() if r.get("resourceType") == "MedicationRequest"]
        encounters = [r for r in resources.values() if r.get("resourceType") == "Encounter"]
        careplans = [r for r in resources.values() if r.get("resourceType") == "CarePlan"]

        condition_names = [self._code_display(r.get("code", {})) for r in conditions]
        active_meds = [self._code_display(r.get("medicationCodeableConcept", {}))
                       for r in meds if r.get("status") == "active"]
        careplan_names = [self._category_display(r) for r in careplans]

        text = f"""PATIENT SUMMARY
Name: {name}
Gender: {gender}
Date of Birth: {birth}
{'Deceased: ' + deceased if deceased else 'Status: Alive'}

ACTIVE CONDITIONS ({len(conditions)}):
{chr(10).join(f'  - {c}' for c in condition_names) if condition_names else '  None documented'}

ACTIVE MEDICATIONS ({len(active_meds)}):
{chr(10).join(f'  - {m}' for m in active_meds) if active_meds else '  None'}

TOTAL ENCOUNTERS: {len(encounters)}
ACTIVE CARE PLANS: {', '.join(careplan_names) if careplan_names else 'None'}
"""

        return DocumentChunk(
            content=text.strip(),
            source_type=SourceType.CLINICAL_NOTE,
            metadata={**meta, "chunk_type": "patient_summary"},
        )

    def _build_condition_chunk(self, condition: dict, meta: dict) -> DocumentChunk | None:
        """Build a chunk for a single condition."""
        display = self._code_display(condition.get("code", {}))
        coding = self._code_coding(condition.get("code", {}))
        status = condition.get("clinicalStatus", {})
        status_code = self._code_display(status) if isinstance(status, dict) else str(status)
        onset = condition.get("onsetDateTime", "unknown")
        abatement = condition.get("abatementDateTime", "")

        text = (
            f"DIAGNOSIS: {display}\n"
            f"Code: {coding.get('code', '')} ({coding.get('system', '')})\n"
            f"Clinical Status: {status_code}\n"
            f"Onset: {onset}\n"
            + (f"Resolved: {abatement}\n" if abatement else "Status: Active/Ongoing\n")
            + f"Patient: {meta['patient_name']} (DOB: {meta['birth_date']})"
        )

        return DocumentChunk(
            content=text,
            source_type=SourceType.CLINICAL_NOTE,
            metadata={**meta, "chunk_type": "condition",
                      "condition_code": coding.get("code", ""),
                      "condition_display": display},
        )

    def _build_medication_summary(self, meds: list[dict], meta: dict) -> DocumentChunk:
        """Build a medication list chunk."""
        active = [m for m in meds if m.get("status") == "active"]
        stopped = [m for m in meds if m.get("status") == "stopped"]

        lines = [f"MEDICATION LIST — Patient: {meta['patient_name']}\n"]
        if active:
            lines.append("ACTIVE MEDICATIONS:")
            for m in active:
                display = self._code_display(m.get("medicationCodeableConcept", {}))
                authored = m.get("authoredOn", "unknown")
                lines.append(f"  - {display} (started: {authored})")

        if stopped:
            lines.append("\nDISCONTINUED MEDICATIONS:")
            for m in stopped:
                display = self._code_display(m.get("medicationCodeableConcept", {}))
                lines.append(f"  - {display}")

        return DocumentChunk(
            content="\n".join(lines),
            source_type=SourceType.CLINICAL_NOTE,
            metadata={**meta, "chunk_type": "medication_list",
                      "active_count": len(active), "stopped_count": len(stopped)},
        )

    def _build_encounter_chunk(self, encounter: dict, meta: dict) -> DocumentChunk | None:
        """Build a chunk for a single encounter."""
        enc_type = ""
        for t in encounter.get("type", []):
            enc_type = self._code_display(t)
            break

        enc_class = encounter.get("class", {})
        enc_class_code = enc_class.get("code", "") if isinstance(enc_class, dict) else str(enc_class)
        period = encounter.get("period", {})
        start = period.get("start", "unknown")
        end = period.get("end", "")

        reasons = []
        for rc in encounter.get("reasonCode", []):
            reasons.append(self._code_display(rc))

        text = (
            f"ENCOUNTER: {enc_type}\n"
            f"Class: {enc_class_code}\n"
            f"Date: {start}" + (f" to {end}" if end else "") + "\n"
            f"Patient: {meta['patient_name']}\n"
            + (f"Reason: {', '.join(reasons)}\n" if reasons else "")
        )

        return DocumentChunk(
            content=text,
            source_type=SourceType.CLINICAL_NOTE,
            metadata={**meta, "chunk_type": "encounter",
                      "encounter_class": enc_class_code,
                      "encounter_date": start[:10] if start else ""},
        )

    def _build_observation_chunk(
        self, observations: list[dict], date_str: str, meta: dict
    ) -> DocumentChunk | None:
        """Build a combined observation chunk for a given date."""
        if not observations:
            return None

        lines = [f"OBSERVATIONS — {meta['patient_name']} — Date: {date_str}\n"]
        for obs in observations:
            display = self._code_display(obs.get("code", {}))
            value_qty = obs.get("valueQuantity", {})
            value = value_qty.get("value", "")
            unit = value_qty.get("unit", "")
            lines.append(f"  {display}: {value} {unit}")

        return DocumentChunk(
            content="\n".join(lines),
            source_type=SourceType.CLINICAL_NOTE,
            metadata={**meta, "chunk_type": "observations", "observation_date": date_str},
        )

    def _build_careplan_chunk(self, careplan: dict, meta: dict) -> DocumentChunk | None:
        """Build a chunk for a single care plan."""
        display = self._category_display(careplan)
        status = careplan.get("status", "unknown")
        period = careplan.get("period", {})
        start = period.get("start", "unknown")

        activities = []
        for act in careplan.get("activity", []):
            detail = act.get("detail", {})
            desc = detail.get("description", "")
            if desc:
                activities.append(desc)

        text = (
            f"CARE PLAN: {display}\n"
            f"Status: {status}\n"
            f"Start: {start}\n"
            f"Patient: {meta['patient_name']}\n\n"
            "Activities:\n"
            + "\n".join(f"  - {a}" for a in activities) if activities else "  None specified"
        )

        return DocumentChunk(
            content=text,
            source_type=SourceType.CLINICAL_NOTE,
            metadata={**meta, "chunk_type": "careplan", "careplan_display": display},
        )

    # ── FHIR utility helpers ─────────────────────────────────────────

    @staticmethod
    def _extract_patient_name(patient: dict) -> str:
        names = patient.get("name", [])
        if names:
            n = names[0]
            given = " ".join(n.get("given", []))
            family = n.get("family", "")
            return f"{given} {family}".strip()
        return "Unknown"

    @staticmethod
    def _code_display(codeable_concept: dict) -> str:
        codings = codeable_concept.get("coding", [])
        if codings:
            return codings[0].get("display", codings[0].get("code", ""))
        return codeable_concept.get("text", "unknown")

    @staticmethod
    def _code_coding(codeable_concept: dict) -> dict:
        codings = codeable_concept.get("coding", [])
        return codings[0] if codings else {}

    @staticmethod
    def _category_display(resource: dict) -> str:
        categories = resource.get("category", [])
        if categories:
            return FHIRBundleParser._code_display(categories[0])
        return "Unknown"
