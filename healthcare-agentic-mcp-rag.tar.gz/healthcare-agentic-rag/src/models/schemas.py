"""
Domain models and state schemas shared across agents.

These Pydantic models serve as the single source of truth for data flowing
through the LangGraph workflow.  Every agent reads from and writes to the
shared ``AgentState`` TypedDict, which LangGraph serialises between nodes.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any, TypedDict

from pydantic import BaseModel, Field


# ── Enumerations ─────────────────────────────────────────────────────

class SourceType(StrEnum):
    CLINICAL_NOTE = "clinical_note"
    DRUG_REFERENCE = "drug_reference"
    ICD_CODE = "icd_code"
    GUIDELINE = "guideline"
    EXTERNAL_API = "external_api"


class PlanStepStatus(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class AgentRole(StrEnum):
    ORCHESTRATOR = "orchestrator"
    RETRIEVAL = "retrieval"
    TOOL_SELECTION = "tool_selection"
    SYNTHESIS = "synthesis"
    VALIDATION = "validation"


# ── Document / Retrieval Models ──────────────────────────────────────

class DocumentChunk(BaseModel):
    """A single chunk stored in the vector DB / returned by retrieval."""

    chunk_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    content: str
    source_type: SourceType
    metadata: dict[str, Any] = Field(default_factory=dict)
    score: float = 0.0  # relevance score after retrieval / reranking


class RetrievalResult(BaseModel):
    """Aggregated output of the retrieval agent."""

    chunks: list[DocumentChunk] = Field(default_factory=list)
    query_used: str = ""
    strategy: str = "hybrid"  # hybrid | vector_only | bm25_only


# ── Planning Models ──────────────────────────────────────────────────

class PlanStep(BaseModel):
    """A single step in the orchestrator's execution plan."""

    step_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:8])
    agent: AgentRole
    description: str
    input_keys: list[str] = Field(default_factory=list)
    status: PlanStepStatus = PlanStepStatus.PENDING
    result: Any = None
    error: str | None = None


class ExecutionPlan(BaseModel):
    """Full plan produced by the orchestrator."""

    plan_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:8])
    query: str
    steps: list[PlanStep] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    replan_count: int = 0


# ── Tool Selection Models ────────────────────────────────────────────

class ToolCall(BaseModel):
    """Record of a single tool invocation."""

    tool_name: str
    arguments: dict[str, Any] = Field(default_factory=dict)
    result: Any = None
    latency_ms: float = 0.0
    success: bool = True
    error: str | None = None


class ToolSelectionResult(BaseModel):
    """Output of the tool-selection agent."""

    calls: list[ToolCall] = Field(default_factory=list)
    reasoning: str = ""


# ── Synthesis Models ─────────────────────────────────────────────────

class Citation(BaseModel):
    """A citation grounding a claim to a source chunk."""

    chunk_id: str
    source_type: SourceType
    excerpt: str  # short excerpt from source
    relevance: float = 1.0


class SynthesisResult(BaseModel):
    """Output of the synthesis agent."""

    answer: str
    citations: list[Citation] = Field(default_factory=list)
    confidence: float = 0.0


# ── Validation Models ────────────────────────────────────────────────

class ValidationVerdict(BaseModel):
    """Output of the validation agent."""

    is_faithful: bool = True
    faithfulness_score: float = 1.0
    flagged_claims: list[str] = Field(default_factory=list)
    reasoning: str = ""


# ── LangGraph State ──────────────────────────────────────────────────

class AgentState(TypedDict, total=False):
    """
    Shared state that flows through the LangGraph workflow.

    LangGraph serialises this dict between nodes; each agent reads what it
    needs and writes its outputs back.
    """

    # Input
    query: str
    session_id: str

    # Planning
    plan: dict  # serialised ExecutionPlan
    current_step_index: int
    replan_count: int

    # Retrieval
    retrieval_result: dict  # serialised RetrievalResult

    # Tool selection
    tool_selection_result: dict  # serialised ToolSelectionResult

    # Synthesis
    synthesis_result: dict  # serialised SynthesisResult

    # Validation
    validation_verdict: dict  # serialised ValidationVerdict

    # Control flow
    needs_replan: bool
    final_answer: str
    error: str | None

    # Observability
    trace: list[dict]


# ── API Request / Response ───────────────────────────────────────────

class QueryRequest(BaseModel):
    query: str = Field(..., min_length=3, max_length=2000)
    session_id: str = Field(default_factory=lambda: uuid.uuid4().hex)


class QueryResponse(BaseModel):
    answer: str
    citations: list[Citation] = Field(default_factory=list)
    confidence: float
    faithfulness_score: float
    plan_steps: int
    replan_count: int
    session_id: str


class IngestRequest(BaseModel):
    source_type: SourceType
    documents: list[dict[str, Any]]


class IngestResponse(BaseModel):
    ingested: int
    collection: str
