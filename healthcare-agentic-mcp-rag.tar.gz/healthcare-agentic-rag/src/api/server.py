"""
FastAPI server — the production gateway for the agentic RAG pipeline.

Endpoints:
  POST /query   — Run a clinical query through the full agent graph
  POST /ingest  — Ingest new documents into the vector store
  GET  /health  — Health check
"""

from __future__ import annotations

import time
import uuid
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from src.config import get_settings
from src.config.logging import setup_logging, get_logger
from src.graph.workflow import run_query
from src.models.schemas import (
    Citation,
    IngestRequest,
    IngestResponse,
    QueryRequest,
    QueryResponse,
    DocumentChunk,
)
from src.tools.file_loader import FileLoader
from src.tools.vector_store import VectorStore

logger = get_logger(__name__)

# ── Shared state ─────────────────────────────────────────────────────
_store: VectorStore | None = None


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application startup / shutdown lifecycle."""
    global _store
    settings = get_settings()
    setup_logging(settings.log_level)

    logger.info("server_starting", port=settings.api_port)

    # Initialise vector store and rebuild BM25 from persisted data
    _store = VectorStore()
    _store.rebuild_bm25_from_collection()

    logger.info("server_ready", collection=settings.chroma_collection)
    yield
    logger.info("server_shutting_down")


def create_app() -> FastAPI:
    """Factory for the FastAPI application."""
    app = FastAPI(
        title="Healthcare Agentic RAG",
        version="0.1.0",
        description="Multi-agent RAG for clinical decision support",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── POST /query ──────────────────────────────────────────────────

    @app.post("/query", response_model=QueryResponse)
    async def query_endpoint(request: QueryRequest) -> QueryResponse:
        """Run a clinical query through the agentic RAG pipeline."""
        t0 = time.perf_counter()
        session_id = request.session_id or uuid.uuid4().hex

        logger.info("query_received", query=request.query[:100], session_id=session_id)

        try:
            state = await run_query(request.query, vector_store=_store)
        except Exception as exc:
            logger.error("query_failed", error=str(exc), session_id=session_id)
            raise HTTPException(status_code=500, detail=str(exc)) from exc

        elapsed = time.perf_counter() - t0
        logger.info("query_complete", latency_s=round(elapsed, 2), session_id=session_id)

        # Extract results from state
        synthesis = state.get("synthesis_result", {})
        validation = state.get("validation_verdict", {})
        plan = state.get("plan", {})

        citations = []
        for c in synthesis.get("citations", []):
            try:
                citations.append(Citation(**c))
            except Exception:
                pass

        return QueryResponse(
            answer=state.get("final_answer", "No answer generated."),
            citations=citations,
            confidence=synthesis.get("confidence", 0.0),
            faithfulness_score=validation.get("faithfulness_score", 0.0),
            plan_steps=len(plan.get("steps", [])),
            replan_count=state.get("replan_count", 0),
            session_id=session_id,
        )

    # ── POST /ingest ─────────────────────────────────────────────────

    @app.post("/ingest", response_model=IngestResponse)
    async def ingest_endpoint(request: IngestRequest) -> IngestResponse:
        """Ingest new documents into the vector store."""
        if _store is None:
            raise HTTPException(status_code=503, detail="Vector store not initialised")

        chunks: list[DocumentChunk] = []
        for doc in request.documents:
            text = doc.get("text", doc.get("content", ""))
            if text:
                metadata = {k: v for k, v in doc.items() if k not in ("text", "content")}
                chunks.append(
                    DocumentChunk(
                        content=text,
                        source_type=request.source_type,
                        metadata=metadata,
                    )
                )

        count = _store.ingest(chunks)
        settings = get_settings()

        logger.info("ingest_complete", count=count)
        return IngestResponse(
            ingested=count,
            collection=settings.chroma_collection,
        )

    # ── GET /health ──────────────────────────────────────────────────

    @app.get("/health")
    async def health() -> dict:
        settings = get_settings()
        doc_count = _store.collection.count() if _store else 0
        return {
            "status": "ok",
            "collection": settings.chroma_collection,
            "documents": doc_count,
            "llm_provider": settings.llm_provider.value,
            "llm_model": settings.llm_model,
        }

    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn

    settings = get_settings()
    uvicorn.run(
        "src.api.server:app",
        host=settings.api_host,
        port=settings.api_port,
        workers=1,  # single worker for development
        reload=True,
    )
