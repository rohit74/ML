"""
Centralized configuration loaded from environment / .env file.

Usage:
    from src.config.settings import get_settings
    settings = get_settings()
"""

from __future__ import annotations

from functools import lru_cache
from enum import StrEnum
from pathlib import Path

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


_PROJECT_ROOT = Path(__file__).resolve().parents[2]


class LLMProvider(StrEnum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"


class EmbeddingProvider(StrEnum):
    LOCAL = "local"
    OPENAI = "openai"


class Settings(BaseSettings):
    """Application-wide settings with validation."""

    model_config = SettingsConfigDict(
        env_file=str(_PROJECT_ROOT / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ── LLM ──────────────────────────────────────────────────────────
    llm_provider: LLMProvider = LLMProvider.ANTHROPIC
    openai_api_key: SecretStr = SecretStr("")
    anthropic_api_key: SecretStr = SecretStr("")
    llm_model: str = "claude-sonnet-4-20250514"
    llm_temperature: float = 0.1
    llm_max_tokens: int = 4096

    # ── Embeddings ───────────────────────────────────────────────────
    embedding_provider: EmbeddingProvider = EmbeddingProvider.LOCAL
    openai_embedding_model: str = "text-embedding-3-small"
    local_embedding_model: str = "all-MiniLM-L6-v2"
    embedding_dimension: int = 384  # MiniLM default

    # ── ChromaDB ─────────────────────────────────────────────────────
    chroma_persist_dir: Path = _PROJECT_ROOT / "data" / "chroma"
    chroma_collection: str = "healthcare_docs"

    # ── MCP ───────────────────────────────────────────────────────────
    mcp_server_host: str = "0.0.0.0"
    mcp_server_port: int = 8001

    # ── API ───────────────────────────────────────────────────────────
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    api_workers: int = 4

    # ── Retrieval ─────────────────────────────────────────────────────
    retrieval_top_k: int = 10
    rerank_top_k: int = 5
    bm25_weight: float = 0.3
    vector_weight: float = 0.7

    # ── Validation ────────────────────────────────────────────────────
    hallucination_threshold: float = 0.7
    max_replan_attempts: int = 2

    # ── Observability ─────────────────────────────────────────────────
    log_level: str = "INFO"
    langsmith_tracing: bool = False
    langsmith_api_key: SecretStr = SecretStr("")
    langsmith_project: str = "healthcare-agentic-rag"

    # ── Derived helpers ───────────────────────────────────────────────
    @property
    def project_root(self) -> Path:
        return _PROJECT_ROOT

    @property
    def sample_data_dir(self) -> Path:
        return _PROJECT_ROOT / "data" / "sample"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return cached singleton settings instance."""
    return Settings()
