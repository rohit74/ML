"""
Evaluation framework for the Agentic RAG pipeline.

Metrics:
  - Answer Relevance: does the answer address the query?
  - Topic Coverage: what fraction of expected topics are mentioned?
  - Faithfulness Score: from the validation agent
  - Citation Precision: ratio of valid citations to total claims
  - Latency: end-to-end wall-clock time

Usage:
    python scripts/run_eval.py --dataset data/sample/eval_queries.json
"""

from __future__ import annotations

import asyncio
import json
import statistics
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from src.config.logging import get_logger
from src.graph.workflow import run_query
from src.tools.vector_store import VectorStore

logger = get_logger(__name__)


@dataclass
class EvalResult:
    """Result of evaluating a single query."""

    query: str
    answer: str
    expected_topics: list[str]
    topics_found: list[str]
    topics_missing: list[str]
    topic_coverage: float
    confidence: float
    faithfulness_score: float
    citation_count: int
    plan_steps: int
    replan_count: int
    latency_s: float
    passed: bool


@dataclass
class EvalSummary:
    """Aggregate evaluation metrics."""

    total_queries: int = 0
    passed: int = 0
    failed: int = 0
    avg_topic_coverage: float = 0.0
    avg_confidence: float = 0.0
    avg_faithfulness: float = 0.0
    avg_citations: float = 0.0
    avg_latency_s: float = 0.0
    p50_latency_s: float = 0.0
    p99_latency_s: float = 0.0
    results: list[EvalResult] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_queries": self.total_queries,
            "passed": self.passed,
            "failed": self.failed,
            "pass_rate": round(self.passed / max(self.total_queries, 1), 3),
            "avg_topic_coverage": round(self.avg_topic_coverage, 3),
            "avg_confidence": round(self.avg_confidence, 3),
            "avg_faithfulness": round(self.avg_faithfulness, 3),
            "avg_citations": round(self.avg_citations, 1),
            "avg_latency_s": round(self.avg_latency_s, 2),
            "p50_latency_s": round(self.p50_latency_s, 2),
            "p99_latency_s": round(self.p99_latency_s, 2),
        }


class Evaluator:
    """Run evaluation queries and compute aggregate metrics."""

    def __init__(self, vector_store: VectorStore | None = None) -> None:
        self._store = vector_store or VectorStore()

    async def evaluate_dataset(self, dataset_path: Path) -> EvalSummary:
        """Load and evaluate all queries in a dataset file."""
        with dataset_path.open() as f:
            queries = json.load(f)

        results: list[EvalResult] = []
        for item in queries:
            result = await self._evaluate_single(item)
            results.append(result)
            logger.info(
                "eval_query_complete",
                query=item["query"][:60],
                coverage=round(result.topic_coverage, 2),
                passed=result.passed,
            )

        return self._compute_summary(results)

    async def _evaluate_single(self, item: dict[str, Any]) -> EvalResult:
        """Evaluate a single query against expected topics."""
        query = item["query"]
        expected_topics = item.get("expected_topics", [])

        t0 = time.perf_counter()
        try:
            state = await run_query(query, vector_store=self._store)
        except Exception as exc:
            logger.error("eval_query_failed", query=query[:60], error=str(exc))
            return EvalResult(
                query=query,
                answer=f"ERROR: {exc}",
                expected_topics=expected_topics,
                topics_found=[],
                topics_missing=expected_topics,
                topic_coverage=0.0,
                confidence=0.0,
                faithfulness_score=0.0,
                citation_count=0,
                plan_steps=0,
                replan_count=0,
                latency_s=time.perf_counter() - t0,
                passed=False,
            )

        latency = time.perf_counter() - t0
        answer = state.get("final_answer", "")
        synthesis = state.get("synthesis_result", {})
        validation = state.get("validation_verdict", {})
        plan = state.get("plan", {})

        # Topic coverage
        answer_lower = answer.lower()
        topics_found = [t for t in expected_topics if t.lower() in answer_lower]
        topics_missing = [t for t in expected_topics if t.lower() not in answer_lower]
        coverage = len(topics_found) / max(len(expected_topics), 1)

        # Pass criteria: >= 50% topic coverage AND faithfulness >= 0.5
        faithfulness = validation.get("faithfulness_score", 0.0)
        passed = coverage >= 0.5 and faithfulness >= 0.5

        return EvalResult(
            query=query,
            answer=answer[:500],
            expected_topics=expected_topics,
            topics_found=topics_found,
            topics_missing=topics_missing,
            topic_coverage=coverage,
            confidence=synthesis.get("confidence", 0.0),
            faithfulness_score=faithfulness,
            citation_count=len(synthesis.get("citations", [])),
            plan_steps=len(plan.get("steps", [])),
            replan_count=state.get("replan_count", 0),
            latency_s=latency,
            passed=passed,
        )

    @staticmethod
    def _compute_summary(results: list[EvalResult]) -> EvalSummary:
        """Compute aggregate metrics from individual results."""
        if not results:
            return EvalSummary()

        latencies = [r.latency_s for r in results]
        sorted_lat = sorted(latencies)
        n = len(sorted_lat)

        return EvalSummary(
            total_queries=len(results),
            passed=sum(1 for r in results if r.passed),
            failed=sum(1 for r in results if not r.passed),
            avg_topic_coverage=statistics.mean(r.topic_coverage for r in results),
            avg_confidence=statistics.mean(r.confidence for r in results),
            avg_faithfulness=statistics.mean(r.faithfulness_score for r in results),
            avg_citations=statistics.mean(r.citation_count for r in results),
            avg_latency_s=statistics.mean(latencies),
            p50_latency_s=sorted_lat[n // 2] if n else 0,
            p99_latency_s=sorted_lat[int(n * 0.99)] if n else 0,
            results=results,
        )
