"""
Model Context Protocol (MCP) server exposing clinical tools as
JSON-RPC 2.0 endpoints.

The MCP server wraps ClinicalAPI into a standards-compliant tool
interface that any MCP-compatible LLM client can discover and invoke.

Protocol: JSON-RPC 2.0 over HTTP (SSE transport for production;
simple HTTP POST for this implementation).
"""

from __future__ import annotations

import json
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from src.config import get_settings
from src.config.logging import get_logger
from src.tools.clinical_api import ClinicalAPI

logger = get_logger(__name__)

# ── Tool Definitions (MCP schema) ───────────────────────────────────

MCP_TOOLS: list[dict[str, Any]] = [
    {
        "name": "lookup_drug_interactions",
        "description": (
            "Look up known drug-drug interactions for a given medication. "
            "Returns severity, description, and management recommendations."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "drug_name": {
                    "type": "string",
                    "description": "Name of the drug to look up (e.g. 'metformin')",
                }
            },
            "required": ["drug_name"],
        },
    },
    {
        "name": "search_icd_codes",
        "description": (
            "Search ICD-10 diagnosis codes by keyword. "
            "Returns matching codes and their descriptions."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search keyword (e.g. 'diabetes', 'E11')",
                }
            },
            "required": ["query"],
        },
    },
    {
        "name": "get_clinical_guideline",
        "description": (
            "Retrieve evidence-based clinical guidelines for a condition. "
            "Returns treatment protocols and recommendations."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "condition": {
                    "type": "string",
                    "description": "Clinical condition (e.g. 'hypertension', 'type 2 diabetes')",
                }
            },
            "required": ["condition"],
        },
    },
]


def create_mcp_app() -> FastAPI:
    """Create and return the MCP FastAPI application."""

    app = FastAPI(title="Healthcare MCP Server", version="0.1.0")
    clinical_api = ClinicalAPI()

    # ── MCP: List available tools ────────────────────────────────────

    @app.post("/mcp/tools/list")
    async def list_tools() -> JSONResponse:
        return JSONResponse({"tools": MCP_TOOLS})

    # ── MCP: Invoke a tool ───────────────────────────────────────────

    @app.post("/mcp/tools/call")
    async def call_tool(request: Request) -> JSONResponse:
        body = await request.json()
        tool_name = body.get("name", "")
        arguments = body.get("arguments", {})

        logger.info("mcp_tool_call", tool=tool_name, args=arguments)

        dispatch = {
            "lookup_drug_interactions": lambda args: clinical_api.lookup_drug_interactions(
                args["drug_name"]
            ),
            "search_icd_codes": lambda args: clinical_api.search_icd_codes(
                args["query"]
            ),
            "get_clinical_guideline": lambda args: clinical_api.get_guideline(
                args["condition"]
            ),
        }

        handler = dispatch.get(tool_name)
        if handler is None:
            return JSONResponse(
                {"error": f"Unknown tool: {tool_name}"},
                status_code=400,
            )

        try:
            result = handler(arguments)
            return JSONResponse({
                "content": [{"type": "text", "text": json.dumps(result, indent=2)}],
                "isError": False,
            })
        except Exception as exc:
            logger.error("mcp_tool_error", tool=tool_name, error=str(exc))
            return JSONResponse(
                {"content": [{"type": "text", "text": str(exc)}], "isError": True},
                status_code=500,
            )

    # ── MCP: Health check ────────────────────────────────────────────

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok", "service": "healthcare-mcp-server"}

    return app


class MCPClient:
    """
    Client for calling tools on the MCP server.

    Used by the ToolSelectionAgent to dynamically invoke clinical tools
    without hardcoding them in the agent's own logic.
    """

    def __init__(self, base_url: str | None = None) -> None:
        settings = get_settings()
        self.base_url = base_url or f"http://{settings.mcp_server_host}:{settings.mcp_server_port}"
        self._tools: list[dict[str, Any]] | None = None

    async def list_tools(self) -> list[dict[str, Any]]:
        """Fetch available tools from the MCP server."""
        import httpx

        async with httpx.AsyncClient() as client:
            resp = await client.post(f"{self.base_url}/mcp/tools/list")
            resp.raise_for_status()
            data = resp.json()
            self._tools = data.get("tools", [])
            return self._tools

    async def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """Invoke a tool on the MCP server and return parsed result."""
        import httpx

        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                f"{self.base_url}/mcp/tools/call",
                json={"name": tool_name, "arguments": arguments},
            )
            resp.raise_for_status()
            data = resp.json()

        if data.get("isError"):
            raise RuntimeError(f"MCP tool error: {data}")

        # Parse the text content back to structured data
        content = data.get("content", [])
        if content and content[0].get("type") == "text":
            return json.loads(content[0]["text"])
        return data

    def get_tool_descriptions(self) -> list[dict[str, str]]:
        """Return a simplified list of tool name + description for the LLM."""
        if self._tools is None:
            return []
        return [
            {"name": t["name"], "description": t["description"]}
            for t in self._tools
        ]
