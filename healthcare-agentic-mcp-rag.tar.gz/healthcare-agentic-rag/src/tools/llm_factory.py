"""
LLM factory — returns the configured LangChain chat model.

Supports OpenAI and Anthropic backends; selection controlled by
settings.llm_provider.
"""

from __future__ import annotations

from functools import lru_cache

from langchain_core.language_models import BaseChatModel

from src.config import get_settings, LLMProvider


@lru_cache(maxsize=1)
def get_llm() -> BaseChatModel:
    """Return a singleton LangChain chat model based on config."""
    settings = get_settings()

    if settings.llm_provider == LLMProvider.OPENAI:
        from langchain_openai import ChatOpenAI

        return ChatOpenAI(
            model=settings.llm_model,
            temperature=settings.llm_temperature,
            max_tokens=settings.llm_max_tokens,
            api_key=settings.openai_api_key.get_secret_value(),
        )

    # Default: Anthropic
    from langchain_anthropic import ChatAnthropic

    return ChatAnthropic(
        model=settings.llm_model,
        temperature=settings.llm_temperature,
        max_tokens=settings.llm_max_tokens,
        api_key=settings.anthropic_api_key.get_secret_value(),
    )
