"""
File loader tool for ingesting clinical documents from disk.

Handles JSON, CSV, plain-text, and Markdown.  Splits long documents
into overlapping chunks suitable for vector embedding.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from src.config.logging import get_logger
from src.models.schemas import DocumentChunk, SourceType

logger = get_logger(__name__)

# ── Chunking parameters ─────────────────────────────────────────────
CHUNK_SIZE = 512  # tokens (approximated as whitespace-split words)
CHUNK_OVERLAP = 64


def _chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split text into overlapping word-level chunks."""
    words = text.split()
    if len(words) <= chunk_size:
        return [text]

    chunks: list[str] = []
    start = 0
    while start < len(words):
        end = start + chunk_size
        chunks.append(" ".join(words[start:end]))
        start += chunk_size - overlap
    return chunks


class FileLoader:
    """Load and chunk healthcare documents from the filesystem."""

    SUPPORTED_EXTENSIONS = {".json", ".csv", ".txt", ".md"}

    def load_directory(
        self,
        directory: Path,
        source_type: SourceType = SourceType.CLINICAL_NOTE,
    ) -> list[DocumentChunk]:
        """Recursively load all supported files from *directory*."""
        chunks: list[DocumentChunk] = []
        if not directory.exists():
            logger.warning("directory_not_found", path=str(directory))
            return chunks

        for path in sorted(directory.rglob("*")):
            if path.suffix in self.SUPPORTED_EXTENSIONS:
                chunks.extend(self.load_file(path, source_type))

        logger.info("loaded_directory", dir=str(directory), chunks=len(chunks))
        return chunks

    def load_file(
        self,
        path: Path,
        source_type: SourceType = SourceType.CLINICAL_NOTE,
    ) -> list[DocumentChunk]:
        """Load a single file and return chunked DocumentChunks."""
        suffix = path.suffix.lower()
        dispatch = {
            ".json": self._load_json,
            ".csv": self._load_csv,
            ".txt": self._load_text,
            ".md": self._load_text,
        }
        loader = dispatch.get(suffix)
        if loader is None:
            logger.warning("unsupported_file", path=str(path))
            return []

        raw_records = loader(path)
        chunks: list[DocumentChunk] = []
        for record in raw_records:
            text = record.pop("text", "")
            for segment in _chunk_text(text):
                chunks.append(
                    DocumentChunk(
                        content=segment,
                        source_type=source_type,
                        metadata={"file": path.name, **record},
                    )
                )
        return chunks

    # ── Format-specific loaders ──────────────────────────────────────

    @staticmethod
    def _load_json(path: Path) -> list[dict[str, Any]]:
        with path.open() as f:
            data = json.load(f)
        if isinstance(data, list):
            return [{"text": json.dumps(item) if not isinstance(item, str) else item} for item in data]
        if isinstance(data, dict):
            # Expect {"documents": [...]} or flat dict
            docs = data.get("documents", [data])
            results = []
            for doc in docs:
                if isinstance(doc, str):
                    results.append({"text": doc})
                elif isinstance(doc, dict):
                    text = doc.pop("text", doc.pop("content", json.dumps(doc)))
                    results.append({"text": text, **{k: v for k, v in doc.items() if isinstance(v, (str, int, float, bool))}})
            return results
        return []

    @staticmethod
    def _load_csv(path: Path) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        with path.open(newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Concatenate all columns into a single text representation
                text_parts = [f"{k}: {v}" for k, v in row.items() if v]
                records.append({"text": " | ".join(text_parts), **row})
        return records

    @staticmethod
    def _load_text(path: Path) -> list[dict[str, Any]]:
        text = path.read_text(encoding="utf-8", errors="replace")
        return [{"text": text}]
