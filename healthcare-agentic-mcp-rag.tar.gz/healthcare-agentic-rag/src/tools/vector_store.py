"""
Vector store tool backed by ChromaDB with hybrid (vector + BM25) retrieval.

Supports:
  - Embedding via local SentenceTransformer or OpenAI
  - Dense vector search
  - Sparse BM25 search
  - Reciprocal Rank Fusion for hybrid merging
  - Cross-encoder reranking
"""

from __future__ import annotations

import hashlib
from typing import Any

import chromadb
import numpy as np
from chromadb.config import Settings as ChromaSettings
from rank_bm25 import BM25Okapi
from sentence_transformers import CrossEncoder, SentenceTransformer

from src.config import get_settings
from src.config.logging import get_logger
from src.models.schemas import DocumentChunk, SourceType

logger = get_logger(__name__)


class VectorStore:
    """ChromaDB-backed vector store with hybrid retrieval."""

    def __init__(self) -> None:
        self._settings = get_settings()
        self._embedder: SentenceTransformer | None = None
        self._reranker: CrossEncoder | None = None
        self._client: chromadb.ClientAPI | None = None
        self._bm25_corpus: list[list[str]] = []
        self._bm25_docs: list[DocumentChunk] = []
        self._bm25_index: BM25Okapi | None = None

    # ── Lazy initialisation ──────────────────────────────────────────

    @property
    def embedder(self) -> SentenceTransformer:
        if self._embedder is None:
            model_name = self._settings.local_embedding_model
            logger.info("loading_embedder", model=model_name)
            self._embedder = SentenceTransformer(model_name)
        return self._embedder

    @property
    def reranker(self) -> CrossEncoder:
        if self._reranker is None:
            self._reranker = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")
        return self._reranker

    @property
    def client(self) -> chromadb.ClientAPI:
        if self._client is None:
            persist_dir = str(self._settings.chroma_persist_dir)
            self._client = chromadb.Client(
                ChromaSettings(
                    persist_directory=persist_dir,
                    anonymized_telemetry=False,
                    is_persistent=True,
                )
            )
        return self._client

    @property
    def collection(self) -> chromadb.Collection:
        return self.client.get_or_create_collection(
            name=self._settings.chroma_collection,
            metadata={"hnsw:space": "cosine"},
        )

    # ── Ingestion ────────────────────────────────────────────────────

    def ingest(self, chunks: list[DocumentChunk]) -> int:
        """Embed and store document chunks. Returns count ingested."""
        if not chunks:
            return 0

        texts = [c.content for c in chunks]
        embeddings = self.embedder.encode(texts, show_progress_bar=False).tolist()
        ids = [self._stable_id(c) for c in chunks]
        metadatas = [
            {"source_type": c.source_type.value, **c.metadata} for c in chunks
        ]

        self.collection.upsert(
            ids=ids,
            documents=texts,
            embeddings=embeddings,
            metadatas=metadatas,
        )

        # Update BM25 index
        self._bm25_corpus.extend([t.lower().split() for t in texts])
        self._bm25_docs.extend(chunks)
        self._bm25_index = BM25Okapi(self._bm25_corpus) if self._bm25_corpus else None

        logger.info("ingested_chunks", count=len(chunks))
        return len(chunks)

    # ── Retrieval ────────────────────────────────────────────────────

    def vector_search(self, query: str, top_k: int | None = None) -> list[DocumentChunk]:
        """Pure dense vector search."""
        top_k = top_k or self._settings.retrieval_top_k
        embedding = self.embedder.encode([query]).tolist()

        results = self.collection.query(
            query_embeddings=embedding,
            n_results=min(top_k, self.collection.count() or 1),
            include=["documents", "metadatas", "distances"],
        )

        return self._chroma_to_chunks(results)

    def bm25_search(self, query: str, top_k: int | None = None) -> list[DocumentChunk]:
        """Sparse BM25 keyword search."""
        top_k = top_k or self._settings.retrieval_top_k
        if self._bm25_index is None or not self._bm25_docs:
            return []

        tokenised_query = query.lower().split()
        scores = self._bm25_index.get_scores(tokenised_query)
        top_indices = np.argsort(scores)[::-1][:top_k]

        results: list[DocumentChunk] = []
        for idx in top_indices:
            if scores[idx] > 0:
                chunk = self._bm25_docs[idx].model_copy()
                chunk.score = float(scores[idx])
                results.append(chunk)
        return results

    def hybrid_search(
        self, query: str, top_k: int | None = None
    ) -> list[DocumentChunk]:
        """Reciprocal Rank Fusion of vector + BM25 results."""
        top_k = top_k or self._settings.retrieval_top_k
        k = 60  # RRF constant

        vector_results = self.vector_search(query, top_k=top_k * 2)
        bm25_results = self.bm25_search(query, top_k=top_k * 2)

        scores: dict[str, float] = {}
        chunk_map: dict[str, DocumentChunk] = {}

        for rank, chunk in enumerate(vector_results):
            cid = chunk.chunk_id
            scores[cid] = scores.get(cid, 0) + self._settings.vector_weight / (k + rank + 1)
            chunk_map[cid] = chunk

        for rank, chunk in enumerate(bm25_results):
            cid = chunk.chunk_id
            scores[cid] = scores.get(cid, 0) + self._settings.bm25_weight / (k + rank + 1)
            if cid not in chunk_map:
                chunk_map[cid] = chunk

        sorted_ids = sorted(scores, key=lambda x: scores[x], reverse=True)[:top_k]
        fused = []
        for cid in sorted_ids:
            chunk = chunk_map[cid].model_copy()
            chunk.score = scores[cid]
            fused.append(chunk)

        return fused

    def rerank(self, query: str, chunks: list[DocumentChunk], top_k: int | None = None) -> list[DocumentChunk]:
        """Cross-encoder reranking of candidate chunks."""
        top_k = top_k or self._settings.rerank_top_k
        if not chunks:
            return []

        pairs = [(query, c.content) for c in chunks]
        scores = self.reranker.predict(pairs).tolist()

        for chunk, score in zip(chunks, scores):
            chunk.score = float(score)

        reranked = sorted(chunks, key=lambda c: c.score, reverse=True)
        return reranked[:top_k]

    # ── Helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _stable_id(chunk: DocumentChunk) -> str:
        """Deterministic ID for deduplication."""
        digest = hashlib.sha256(chunk.content.encode()).hexdigest()[:16]
        return f"{chunk.source_type.value}_{digest}"

    @staticmethod
    def _chroma_to_chunks(results: dict[str, Any]) -> list[DocumentChunk]:
        """Convert ChromaDB query results to DocumentChunk list."""
        chunks: list[DocumentChunk] = []
        if not results or not results.get("documents"):
            return chunks

        for docs, metas, dists in zip(
            results["documents"], results["metadatas"], results["distances"]
        ):
            for doc, meta, dist in zip(docs, metas, dists):
                source_type = SourceType(meta.pop("source_type", "clinical_note"))
                chunks.append(
                    DocumentChunk(
                        content=doc,
                        source_type=source_type,
                        metadata=meta,
                        score=1.0 - dist,  # cosine distance → similarity
                    )
                )
        return chunks

    def rebuild_bm25_from_collection(self) -> None:
        """Rebuild BM25 index from all documents in the ChromaDB collection."""
        count = self.collection.count()
        if count == 0:
            self._bm25_index = None
            return

        all_docs = self.collection.get(include=["documents", "metadatas"])
        self._bm25_corpus = []
        self._bm25_docs = []

        for doc, meta in zip(all_docs["documents"], all_docs["metadatas"]):
            source_type = SourceType(meta.pop("source_type", "clinical_note"))
            chunk = DocumentChunk(content=doc, source_type=source_type, metadata=meta)
            self._bm25_corpus.append(doc.lower().split())
            self._bm25_docs.append(chunk)

        self._bm25_index = BM25Okapi(self._bm25_corpus)
        logger.info("rebuilt_bm25_index", doc_count=count)
