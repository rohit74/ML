"""
Clinical API tool providing structured lookups for:
  - Drug-drug interactions
  - ICD-10 diagnosis code search
  - Clinical guideline retrieval

In production this would call external APIs (e.g. RxNorm, OpenFDA).
Here we use a local reference dataset to keep the project self-contained.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from src.config import get_settings
from src.config.logging import get_logger
from src.models.schemas import DocumentChunk, SourceType

logger = get_logger(__name__)


class ClinicalAPI:
    """Simulated clinical reference API backed by local JSON data."""

    def __init__(self) -> None:
        self._settings = get_settings()
        self._drug_data: list[dict[str, Any]] | None = None
        self._icd_data: list[dict[str, Any]] | None = None
        self._guideline_data: list[dict[str, Any]] | None = None

    # ── Data loading (lazy) ──────────────────────────────────────────

    def _load_json(self, filename: str) -> list[dict[str, Any]]:
        path = self._settings.sample_data_dir / filename
        if not path.exists():
            logger.warning("data_file_missing", path=str(path))
            return []
        with path.open() as f:
            data = json.load(f)
        return data if isinstance(data, list) else data.get("records", [])

    @property
    def drug_data(self) -> list[dict[str, Any]]:
        if self._drug_data is None:
            self._drug_data = self._load_json("drug_interactions.json")
        return self._drug_data

    @property
    def icd_data(self) -> list[dict[str, Any]]:
        if self._icd_data is None:
            self._icd_data = self._load_json("icd10_codes.json")
        return self._icd_data

    @property
    def guideline_data(self) -> list[dict[str, Any]]:
        if self._guideline_data is None:
            self._guideline_data = self._load_json("clinical_guidelines.json")
        return self._guideline_data

    # ── Public API methods ───────────────────────────────────────────

    def lookup_drug_interactions(self, drug_name: str) -> list[dict[str, Any]]:
        """Return known interactions for a given drug (case-insensitive)."""
        drug_lower = drug_name.lower()
        matches = [
            d for d in self.drug_data
            if drug_lower in d.get("drug_a", "").lower()
            or drug_lower in d.get("drug_b", "").lower()
        ]
        logger.info("drug_lookup", drug=drug_name, matches=len(matches))
        return matches

    def search_icd_codes(self, query: str) -> list[dict[str, Any]]:
        """Search ICD-10 codes by keyword in code or description."""
        query_lower = query.lower()
        matches = [
            entry for entry in self.icd_data
            if query_lower in entry.get("code", "").lower()
            or query_lower in entry.get("description", "").lower()
        ]
        logger.info("icd_search", query=query, matches=len(matches))
        return matches[:20]

    def get_guideline(self, condition: str) -> list[dict[str, Any]]:
        """Retrieve clinical guidelines matching a condition keyword."""
        condition_lower = condition.lower()
        matches = [
            g for g in self.guideline_data
            if condition_lower in g.get("condition", "").lower()
            or condition_lower in g.get("title", "").lower()
            or condition_lower in g.get("content", "").lower()
        ]
        logger.info("guideline_lookup", condition=condition, matches=len(matches))
        return matches

    # ── Convert to DocumentChunks (for downstream agents) ────────────

    def interactions_to_chunks(self, drug_name: str) -> list[DocumentChunk]:
        """Return drug interactions as DocumentChunks for synthesis."""
        interactions = self.lookup_drug_interactions(drug_name)
        chunks: list[DocumentChunk] = []
        for inter in interactions:
            text = (
                f"Drug Interaction: {inter.get('drug_a', '')} + {inter.get('drug_b', '')}\n"
                f"Severity: {inter.get('severity', 'unknown')}\n"
                f"Description: {inter.get('description', '')}\n"
                f"Management: {inter.get('management', '')}"
            )
            chunks.append(
                DocumentChunk(
                    content=text,
                    source_type=SourceType.DRUG_REFERENCE,
                    metadata={
                        "drug_a": inter.get("drug_a", ""),
                        "drug_b": inter.get("drug_b", ""),
                        "severity": inter.get("severity", ""),
                    },
                )
            )
        return chunks

    def icd_to_chunks(self, query: str) -> list[DocumentChunk]:
        """Return ICD-10 search results as DocumentChunks."""
        codes = self.search_icd_codes(query)
        return [
            DocumentChunk(
                content=f"ICD-10 {c['code']}: {c['description']}",
                source_type=SourceType.ICD_CODE,
                metadata={"code": c["code"]},
            )
            for c in codes
        ]

    def guideline_to_chunks(self, condition: str) -> list[DocumentChunk]:
        """Return clinical guidelines as DocumentChunks."""
        guidelines = self.get_guideline(condition)
        return [
            DocumentChunk(
                content=g.get("content", g.get("title", "")),
                source_type=SourceType.GUIDELINE,
                metadata={
                    "title": g.get("title", ""),
                    "condition": g.get("condition", ""),
                    "source": g.get("source", ""),
                },
            )
            for g in guidelines
        ]
