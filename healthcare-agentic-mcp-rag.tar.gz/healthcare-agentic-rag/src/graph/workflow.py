"""
LangGraph Workflow — the directed graph that orchestrates all five agents.

Graph topology:
    ┌─────────┐
    │  START   │
    └────┬─────┘
         │
         ▼
    ┌─────────────┐
    │  plan_node   │  (OrchestratorAgent.plan)
    └────┬─────────┘
         │
         ▼
    ┌─────────────┐
    │ route_step   │◄──────────────────────────┐
    └──┬──┬──┬──┬──┘                           │
       │  │  │  │                              │
       ▼  ▼  ▼  ▼                              │
   retrieval / tool_selection                  │
   synthesis / validation                      │
       │  │  │  │                              │
       └──┴──┴──┘                              │
         │                                     │
         ▼                                     │
    ┌──────────────┐    needs_replan=True      │
    │ check_replan  │──────────────────────────┘
    └────┬─────────┘    (via replan_node)
         │ needs_replan=False
         ▼
    ┌─────────┐
    │   END   │
    └─────────┘

Each agent node reads from and writes to the shared AgentState.
Conditional edges implement the re-planning loop.
"""

from __future__ import annotations

from typing import Any, Literal

from langgraph.graph import END, StateGraph

from src.agents.orchestrator import OrchestratorAgent
from src.agents.retrieval import RetrievalAgent
from src.agents.synthesis import SynthesisAgent
from src.agents.tool_selection import ToolSelectionAgent
from src.agents.validation import ValidationAgent
from src.config.logging import get_logger
from src.models.schemas import AgentRole, AgentState
from src.tools.vector_store import VectorStore

logger = get_logger(__name__)


def build_graph(vector_store: VectorStore | None = None) -> StateGraph:
    """
    Construct and compile the LangGraph workflow.

    Parameters
    ----------
    vector_store : VectorStore, optional
        Injected vector store instance (useful for testing).

    Returns
    -------
    CompiledGraph
        A compiled LangGraph ready for ``.ainvoke()``.
    """
    store = vector_store or VectorStore()

    # ── Agent instances ──────────────────────────────────────────────
    orchestrator = OrchestratorAgent()
    retrieval_agent = RetrievalAgent(vector_store=store)
    tool_agent = ToolSelectionAgent()
    synthesis_agent = SynthesisAgent()
    validation_agent = ValidationAgent()

    # ── Node functions ───────────────────────────────────────────────
    # Each node is an async function: AgentState → AgentState

    async def plan_node(state: AgentState) -> AgentState:
        return await orchestrator.plan(state)

    async def replan_node(state: AgentState) -> AgentState:
        return await orchestrator.replan(state)

    async def retrieval_node(state: AgentState) -> AgentState:
        return await retrieval_agent.run(state)

    async def tool_selection_node(state: AgentState) -> AgentState:
        return await tool_agent.run(state)

    async def synthesis_node(state: AgentState) -> AgentState:
        return await synthesis_agent.run(state)

    async def validation_node(state: AgentState) -> AgentState:
        return await validation_agent.run(state)

    async def route_step(state: AgentState) -> AgentState:
        """
        Dispatch the current plan step to the appropriate agent node.
        This is the central router that reads the plan and advances through it.
        """
        step = orchestrator.get_current_step(state)
        if step is None:
            # Plan exhausted — should not happen if plan always ends with validation
            logger.warning("route_step_exhausted")
            return state

        logger.info("routing_step", agent=step.agent, description=step.description[:80])
        state["_current_agent"] = step.agent.value
        return state

    # ── Conditional edge logic ───────────────────────────────────────

    def should_route_to(state: AgentState) -> str:
        """Determine which agent node to invoke next."""
        agent = state.get("_current_agent", "")
        mapping = {
            AgentRole.RETRIEVAL.value: "retrieval",
            AgentRole.TOOL_SELECTION.value: "tool_selection",
            AgentRole.SYNTHESIS.value: "synthesis",
            AgentRole.VALIDATION.value: "validation",
        }
        return mapping.get(agent, "synthesis")

    def check_replan(state: AgentState) -> Literal["replan", "end"]:
        """After validation, decide whether to re-plan or finish."""
        if state.get("needs_replan", False):
            return "replan"
        return "end"

    def after_agent(state: AgentState) -> Literal["route_step", "check_replan"]:
        """After an agent runs, advance the plan and decide next action."""
        state = orchestrator.advance_step(state)

        next_step = orchestrator.get_current_step(state)
        if next_step is None:
            return "check_replan"
        return "route_step"

    # ── Build the graph ──────────────────────────────────────────────

    graph = StateGraph(AgentState)

    # Add nodes
    graph.add_node("plan", plan_node)
    graph.add_node("replan", replan_node)
    graph.add_node("route_step", route_step)
    graph.add_node("retrieval", retrieval_node)
    graph.add_node("tool_selection", tool_selection_node)
    graph.add_node("synthesis", synthesis_node)
    graph.add_node("validation", validation_node)

    # Entry point
    graph.set_entry_point("plan")

    # plan → route_step
    graph.add_edge("plan", "route_step")

    # replan → route_step
    graph.add_edge("replan", "route_step")

    # route_step → conditional dispatch to agent
    graph.add_conditional_edges(
        "route_step",
        should_route_to,
        {
            "retrieval": "retrieval",
            "tool_selection": "tool_selection",
            "synthesis": "synthesis",
            "validation": "validation",
        },
    )

    # Each agent → decide next step or check replan
    for agent_node in ["retrieval", "tool_selection", "synthesis", "validation"]:
        graph.add_conditional_edges(
            agent_node,
            after_agent,
            {
                "route_step": "route_step",
                "check_replan": "check_replan" if agent_node == "validation" else "route_step",
            },
        )

    # Add a dedicated check_replan node
    async def check_replan_node(state: AgentState) -> AgentState:
        """No-op node; routing logic is in the conditional edge."""
        return state

    graph.add_node("check_replan", check_replan_node)

    # check_replan → replan or END
    graph.add_conditional_edges(
        "check_replan",
        check_replan,
        {
            "replan": "replan",
            "end": END,
        },
    )

    return graph.compile()


async def run_query(query: str, vector_store: VectorStore | None = None) -> AgentState:
    """
    Execute the full agentic RAG pipeline for a query.

    Parameters
    ----------
    query : str
        The user's clinical question.
    vector_store : VectorStore, optional
        Pre-initialised vector store.

    Returns
    -------
    AgentState
        The final state containing the answer, citations, and trace.
    """
    graph = build_graph(vector_store=vector_store)

    initial_state: AgentState = {
        "query": query,
        "session_id": "",
        "plan": {},
        "current_step_index": 0,
        "replan_count": 0,
        "retrieval_result": {},
        "tool_selection_result": {},
        "synthesis_result": {},
        "validation_verdict": {},
        "needs_replan": False,
        "final_answer": "",
        "error": None,
        "trace": [],
    }

    logger.info("workflow_start", query=query[:100])
    result = await graph.ainvoke(initial_state)
    logger.info(
        "workflow_complete",
        has_answer=bool(result.get("final_answer")),
        trace_steps=len(result.get("trace", [])),
    )

    # If no final_answer was set (validation never passed), use synthesis as fallback
    if not result.get("final_answer"):
        synthesis = result.get("synthesis_result", {})
        result["final_answer"] = synthesis.get(
            "answer",
            "Unable to generate a validated answer for this query.",
        )

    return result
