#!/usr/bin/env python3
"""
Generate Synthea-format synthetic patient data.

Produces:
  - FHIR R4 Bundle JSON files (one per patient) in data/synthea/fhir/
  - Synthea-format CSV exports in data/synthea/csv/

This mirrors Synthea's actual output schemas so the ingestion pipeline
works identically whether you point it at real Synthea output or this
generated data.

Usage:
    python scripts/generate_synthea_data.py --patients 50
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import sys
import uuid
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

random.seed(42)

# ── Reference Data ───────────────────────────────────────────────────

FIRST_NAMES_M = [
    "James", "Robert", "Michael", "William", "David", "Richard", "Joseph",
    "Thomas", "Christopher", "Daniel", "Matthew", "Anthony", "Mark", "Steven",
    "Andrew", "Kenneth", "Joshua", "Kevin", "Brian", "George", "Timothy",
    "Ronald", "Edward", "Jason", "Jeffrey", "Ryan", "Gary", "Nicholas",
]
FIRST_NAMES_F = [
    "Mary", "Patricia", "Jennifer", "Linda", "Barbara", "Elizabeth", "Susan",
    "Jessica", "Sarah", "Karen", "Lisa", "Nancy", "Betty", "Margaret",
    "Sandra", "Ashley", "Dorothy", "Kimberly", "Emily", "Donna", "Michelle",
    "Carol", "Amanda", "Melissa", "Deborah", "Stephanie", "Rebecca", "Sharon",
]
LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller",
    "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez",
    "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin",
    "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Lewis",
    "Robinson", "Walker", "Young", "Allen", "King", "Wright", "Scott", "Torres",
]

CITIES = [
    ("Boston", "MA", "02101"), ("Springfield", "MA", "01101"),
    ("Worcester", "MA", "01601"), ("Cambridge", "MA", "02138"),
    ("Lowell", "MA", "01850"), ("Brockton", "MA", "02301"),
]

RACES = ["white", "black", "asian", "hispanic", "native", "other"]
ETHNICITIES = ["nonhispanic", "hispanic"]
MARITAL_STATUSES = ["S", "M", "D", "W"]

# ── Clinical Reference Data ─────────────────────────────────────────

CONDITIONS = [
    {"code": "44054006", "display": "Diabetes mellitus type 2", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 35, "onset_age_max": 75},
    {"code": "38341003", "display": "Hypertensive disorder", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 30, "onset_age_max": 80},
    {"code": "84114007", "display": "Heart failure", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 50, "onset_age_max": 85},
    {"code": "13645005", "display": "Chronic obstructive lung disease", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 45, "onset_age_max": 80},
    {"code": "431855005", "display": "Chronic kidney disease stage 1", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 40, "onset_age_max": 80},
    {"code": "431856006", "display": "Chronic kidney disease stage 2", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 45, "onset_age_max": 80},
    {"code": "433144002", "display": "Chronic kidney disease stage 3", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 50, "onset_age_max": 85},
    {"code": "431857002", "display": "Chronic kidney disease stage 4", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 55, "onset_age_max": 85},
    {"code": "73211009", "display": "Diabetes mellitus", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 25, "onset_age_max": 70},
    {"code": "22298006", "display": "Myocardial infarction", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 40, "onset_age_max": 85},
    {"code": "230690007", "display": "Cerebrovascular accident", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 50, "onset_age_max": 90},
    {"code": "195662009", "display": "Acute viral pharyngitis", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 5, "onset_age_max": 60},
    {"code": "10509002", "display": "Acute bronchitis", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 10, "onset_age_max": 70},
    {"code": "40055000", "display": "Chronic sinusitis", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 20, "onset_age_max": 65},
    {"code": "46635009", "display": "Type 1 diabetes mellitus", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 5, "onset_age_max": 30},
    {"code": "49436004", "display": "Atrial fibrillation", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 55, "onset_age_max": 90},
    {"code": "53741008", "display": "Coronary heart disease", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 45, "onset_age_max": 85},
    {"code": "267036007", "display": "Dyspnea", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 30, "onset_age_max": 85},
    {"code": "271737000", "display": "Anemia", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 20, "onset_age_max": 80},
    {"code": "235595009", "display": "Gastroesophageal reflux disease", "system": "http://snomed.info/sct",
     "category": "encounter-diagnosis", "onset_age_min": 25, "onset_age_max": 70},
]

CHRONIC_CONDITIONS = [c for c in CONDITIONS if c["code"] in (
    "44054006", "38341003", "84114007", "13645005", "431855005", "431856006",
    "433144002", "431857002", "49436004", "53741008",
)]

MEDICATIONS = [
    {"code": "860975", "display": "Metformin 500 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["44054006", "73211009"], "base_cost": 5.42},
    {"code": "897718", "display": "Metformin 1000 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["44054006", "73211009"], "base_cost": 8.15},
    {"code": "316672", "display": "Lisinopril 10 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["38341003", "84114007", "431855005", "431856006", "433144002"], "base_cost": 3.20},
    {"code": "316673", "display": "Lisinopril 20 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["38341003", "84114007", "431857002"], "base_cost": 4.50},
    {"code": "429503", "display": "Amlodipine 5 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["38341003"], "base_cost": 6.10},
    {"code": "200031", "display": "Carvedilol 12.5 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["84114007", "38341003"], "base_cost": 7.30},
    {"code": "310798", "display": "Furosemide 40 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["84114007"], "base_cost": 2.85},
    {"code": "311700", "display": "Atorvastatin 20 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["53741008", "44054006"], "base_cost": 4.90},
    {"code": "259255", "display": "Atorvastatin 80 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["22298006", "53741008"], "base_cost": 8.75},
    {"code": "1049221", "display": "Acetaminophen 325 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": [], "base_cost": 1.50},
    {"code": "834101", "display": "Warfarin 5 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["49436004"], "base_cost": 6.50},
    {"code": "1361568", "display": "Apixaban 5 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["49436004", "230690007"], "base_cost": 15.20},
    {"code": "199224", "display": "Omeprazole 20 MG Oral Capsule", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["235595009"], "base_cost": 3.75},
    {"code": "746030", "display": "Albuterol 0.83 MG/ML Inhalation Solution", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["13645005", "267036007"], "base_cost": 12.50},
    {"code": "896188", "display": "Tiotropium Bromide 2.5 MCG Inhalation Spray", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["13645005"], "base_cost": 45.00},
    {"code": "1373463", "display": "Dapagliflozin 10 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["44054006", "84114007", "433144002"], "base_cost": 18.50},
    {"code": "1598268", "display": "Insulin Glargine 100 UNT/ML Injectable Solution", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["44054006", "46635009"], "base_cost": 35.00},
    {"code": "731531", "display": "Aspirin 81 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["22298006", "53741008"], "base_cost": 1.20},
    {"code": "1232586", "display": "Ticagrelor 90 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["22298006"], "base_cost": 12.40},
    {"code": "1049630", "display": "Spironolactone 25 MG Oral Tablet", "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
     "for_conditions": ["84114007"], "base_cost": 5.60},
]

CARE_PLANS = [
    {"code": "698360004", "display": "Diabetes self management plan",
     "for_conditions": ["44054006", "73211009", "46635009"],
     "activities": ["Diabetic diet", "Exercise therapy", "Blood glucose monitoring"]},
    {"code": "443402002", "display": "Lifestyle education regarding hypertension",
     "for_conditions": ["38341003"],
     "activities": ["Low sodium diet", "Physical activity", "Blood pressure monitoring"]},
    {"code": "735984001", "display": "Heart failure care plan",
     "for_conditions": ["84114007"],
     "activities": ["Fluid restriction", "Daily weight monitoring", "Sodium restriction", "Exercise as tolerated"]},
    {"code": "412776001", "display": "Chronic obstructive pulmonary disease clinical management plan",
     "for_conditions": ["13645005"],
     "activities": ["Pulmonary rehabilitation", "Smoking cessation", "Influenza vaccination", "Inhaler technique"]},
    {"code": "734163000", "display": "Care plan for chronic kidney disease",
     "for_conditions": ["431855005", "431856006", "433144002", "431857002"],
     "activities": ["Renal diet", "Fluid monitoring", "Blood pressure control", "Nephrology referral"]},
    {"code": "736285004", "display": "Anticoagulation care plan",
     "for_conditions": ["49436004"],
     "activities": ["INR monitoring", "Medication adherence", "Bleeding precautions", "Diet consistency"]},
    {"code": "408907009", "display": "Smoking cessation plan",
     "for_conditions": ["13645005", "53741008"],
     "activities": ["Nicotine replacement", "Behavioral counseling", "Follow-up tracking"]},
]

ENCOUNTER_TYPES = [
    {"code": "185345009", "display": "Encounter for check up", "class": "ambulatory"},
    {"code": "185347001", "display": "Encounter for problem", "class": "ambulatory"},
    {"code": "50849002", "display": "Emergency room admission", "class": "emergency"},
    {"code": "32485007", "display": "Hospital admission", "class": "inpatient"},
    {"code": "308646001", "display": "Death certification", "class": "ambulatory"},
]

OBSERVATIONS_VITAL_SIGNS = [
    {"code": "8302-2", "display": "Body Height", "unit": "cm", "range": (140, 200)},
    {"code": "29463-7", "display": "Body Weight", "unit": "kg", "range": (50, 140)},
    {"code": "39156-5", "display": "Body mass index", "unit": "kg/m2", "range": (18.5, 45.0)},
    {"code": "85354-9", "display": "Blood pressure panel", "unit": "mmHg", "range": (90, 180)},
    {"code": "8867-4", "display": "Heart rate", "unit": "/min", "range": (55, 110)},
]

OBSERVATIONS_LAB = [
    {"code": "4548-4", "display": "Hemoglobin A1c", "unit": "%", "range": (4.5, 12.0)},
    {"code": "2160-0", "display": "Creatinine", "unit": "mg/dL", "range": (0.6, 4.0)},
    {"code": "33914-3", "display": "eGFR", "unit": "mL/min/{1.73_m2}", "range": (15, 120)},
    {"code": "2345-7", "display": "Glucose", "unit": "mg/dL", "range": (70, 300)},
    {"code": "2571-8", "display": "Triglycerides", "unit": "mg/dL", "range": (50, 400)},
    {"code": "2093-3", "display": "Total Cholesterol", "unit": "mg/dL", "range": (120, 300)},
    {"code": "2085-9", "display": "HDL Cholesterol", "unit": "mg/dL", "range": (25, 90)},
    {"code": "18262-6", "display": "LDL Cholesterol", "unit": "mg/dL", "range": (50, 200)},
    {"code": "6299-2", "display": "BUN", "unit": "mg/dL", "range": (7, 50)},
    {"code": "2823-3", "display": "Potassium", "unit": "mmol/L", "range": (3.2, 6.0)},
    {"code": "2947-0", "display": "Sodium", "unit": "mmol/L", "range": (128, 148)},
    {"code": "33762-6", "display": "NT-proBNP", "unit": "pg/mL", "range": (50, 5000)},
]

PROCEDURES = [
    {"code": "430193006", "display": "Medication reconciliation", "for_encounter": "ambulatory"},
    {"code": "710824005", "display": "Assessment of health and social care needs", "for_encounter": "ambulatory"},
    {"code": "713106006", "display": "Screening for depression", "for_encounter": "ambulatory"},
    {"code": "252160004", "display": "Standard chest X-ray", "for_encounter": "inpatient"},
    {"code": "36969009", "display": "Placement of stent in coronary artery", "for_encounter": "inpatient"},
    {"code": "18286008", "display": "Catheter ablation of heart", "for_encounter": "inpatient"},
    {"code": "232717009", "display": "Coronary artery bypass grafting", "for_encounter": "inpatient"},
    {"code": "76164006", "display": "Biopsy of kidney", "for_encounter": "inpatient"},
]

# ── Clinical Note Templates ─────────────────────────────────────────

def generate_clinical_note(patient: dict, conditions: list, meds: list, encounter: dict, observations: list) -> str:
    """Generate a realistic clinical note from patient data."""
    age = (date.today() - date.fromisoformat(patient["birthdate"])).days // 365
    gender = "Male" if patient["gender"] == "M" else "Female"
    enc_type = encounter["type_display"]

    condition_list = ", ".join(c["display"] for c in conditions) if conditions else "none documented"
    med_list = "\n".join(f"  - {m['display']}" for m in meds) if meds else "  - None"

    obs_text = ""
    for obs in observations:
        obs_text += f"  {obs['display']}: {obs['value']} {obs['unit']}\n"

    note = f"""CLINICAL NOTE — {enc_type}
Patient: {patient['first']} {patient['last']}, {age}{gender[0]}
Date: {encounter['start'][:10]}
MRN: {patient['id'][:8].upper()}

ACTIVE CONDITIONS: {condition_list}

CURRENT MEDICATIONS:
{med_list}

VITALS AND OBSERVATIONS:
{obs_text}
"""

    # Add condition-specific narrative
    cond_codes = {c["code"] for c in conditions}

    if "44054006" in cond_codes or "73211009" in cond_codes:
        a1c = next((o for o in observations if o["code"] == "4548-4"), None)
        a1c_val = f"{a1c['value']}" if a1c else "pending"
        egfr = next((o for o in observations if o["code"] == "33914-3"), None)
        egfr_val = f"{egfr['value']}" if egfr else "pending"

        note += f"""
DIABETES MANAGEMENT:
  HbA1c: {a1c_val}%. eGFR: {egfr_val} mL/min.
  """
        if a1c and a1c["value"] > 8.0:
            note += "  HbA1c above target. Consider therapy intensification.\n"
        if egfr and egfr["value"] < 45:
            note += "  eGFR < 45 — review metformin dosing. Contraindicated if eGFR < 30.\n"
        if egfr and egfr["value"] < 30:
            note += "  eGFR < 30 — DISCONTINUE metformin. Switch to DPP-4 inhibitor or insulin.\n"
            note += "  Consider SGLT2 inhibitor for renoprotection (approved down to eGFR 20 per KDIGO 2024).\n"

    if "84114007" in cond_codes:
        bnp = next((o for o in observations if o["code"] == "33762-6"), None)
        note += f"""
HEART FAILURE ASSESSMENT:
  NT-proBNP: {bnp['value'] if bnp else 'pending'} pg/mL.
  On GDMT: check ACEi/ARB/ARNI, beta-blocker, MRA, SGLT2i.
  """
        if bnp and bnp["value"] > 1000:
            note += "  Elevated BNP. Assess volume status. Consider IV diuresis if decompensated.\n"
            note += "  Hold metformin if concurrent AKI with eGFR < 45.\n"

    if "49436004" in cond_codes:
        note += """
ATRIAL FIBRILLATION:
  CHA2DS2-VASc score calculated. On anticoagulation.
  Verify rate vs rhythm control strategy.
  Monitor INR if on warfarin; no monitoring needed for DOACs.
"""

    if "13645005" in cond_codes:
        note += """
COPD MANAGEMENT:
  Continue maintenance inhaler therapy (LAMA +/- LABA +/- ICS).
  Assess for exacerbation triggers.
  Ensure pneumococcal and influenza vaccinations current.
  Pulmonary rehabilitation referral if not already enrolled.
"""

    if "433144002" in cond_codes or "431857002" in cond_codes:
        note += """
CKD CONSIDERATIONS:
  Review all medications for renal dosing.
  Monitor potassium closely with ACE inhibitor use.
  Low-protein diet (0.8 g/kg/day) recommended.
  Screen for CKD-mineral bone disease (PTH, calcium, phosphorus, vitamin D).
"""

    note += f"""
PLAN:
  Follow-up: {random.choice(['2 weeks', '4 weeks', '3 months', '6 months'])}
  Labs: {random.choice(['HbA1c, BMP in 3 months', 'CBC, CMP, lipid panel', 'Renal panel, urinalysis', 'INR check in 1 week'])}
"""
    return note.strip()


# ── Patient Generator ────────────────────────────────────────────────

class SyntheaGenerator:
    """Generate Synthea-format synthetic healthcare data."""

    def __init__(self, output_dir: Path, num_patients: int = 50) -> None:
        self.output_dir = output_dir
        self.num_patients = num_patients
        self.fhir_dir = output_dir / "fhir"
        self.csv_dir = output_dir / "csv"
        self.fhir_dir.mkdir(parents=True, exist_ok=True)
        self.csv_dir.mkdir(parents=True, exist_ok=True)

        # CSV accumulators
        self.patients_rows: list[dict] = []
        self.conditions_rows: list[dict] = []
        self.medications_rows: list[dict] = []
        self.encounters_rows: list[dict] = []
        self.observations_rows: list[dict] = []
        self.careplans_rows: list[dict] = []
        self.procedures_rows: list[dict] = []
        self.clinical_notes: list[dict] = []

    def generate_all(self) -> None:
        """Generate all patients and write outputs."""
        print(f"Generating {self.num_patients} synthetic patients...")

        for i in range(self.num_patients):
            patient = self._generate_patient(i)
            bundle = self._patient_to_fhir_bundle(patient)

            # Write FHIR bundle
            fhir_path = self.fhir_dir / f"{patient['id']}.json"
            with fhir_path.open("w") as f:
                json.dump(bundle, f, indent=2, default=str)

        # Write CSV files
        self._write_csv("patients.csv", self.patients_rows)
        self._write_csv("conditions.csv", self.conditions_rows)
        self._write_csv("medications.csv", self.medications_rows)
        self._write_csv("encounters.csv", self.encounters_rows)
        self._write_csv("observations.csv", self.observations_rows)
        self._write_csv("careplans.csv", self.careplans_rows)
        self._write_csv("procedures.csv", self.procedures_rows)

        # Write clinical notes as JSON for the RAG pipeline
        notes_path = self.output_dir / "clinical_notes_synthea.json"
        with notes_path.open("w") as f:
            json.dump({"documents": self.clinical_notes}, f, indent=2)

        print(f"\n✓ Generated {self.num_patients} patients")
        print(f"  FHIR bundles: {self.fhir_dir}")
        print(f"  CSV exports:  {self.csv_dir}")
        print(f"  Patients:     {len(self.patients_rows)}")
        print(f"  Conditions:   {len(self.conditions_rows)}")
        print(f"  Medications:  {len(self.medications_rows)}")
        print(f"  Encounters:   {len(self.encounters_rows)}")
        print(f"  Observations: {len(self.observations_rows)}")
        print(f"  Care Plans:   {len(self.careplans_rows)}")
        print(f"  Procedures:   {len(self.procedures_rows)}")
        print(f"  Clinical Notes: {len(self.clinical_notes)}")

    def _generate_patient(self, index: int) -> dict:
        """Generate a single patient with full clinical history."""
        pid = str(uuid.uuid4())
        gender = random.choice(["M", "F"])
        first = random.choice(FIRST_NAMES_M if gender == "M" else FIRST_NAMES_F)
        last = random.choice(LAST_NAMES)
        city, state, zipcode = random.choice(CITIES)
        race = random.choice(RACES)
        ethnicity = random.choice(ETHNICITIES)
        marital = random.choice(MARITAL_STATUSES)

        birth_year = random.randint(1940, 2000)
        birth_month = random.randint(1, 12)
        birth_day = random.randint(1, 28)
        birthdate = date(birth_year, birth_month, birth_day)
        age = (date.today() - birthdate).days // 365

        # Some patients may be deceased
        is_deceased = random.random() < 0.05 and age > 70
        deathdate = (birthdate + timedelta(days=random.randint(365*65, 365*95))).isoformat() if is_deceased else ""

        patient = {
            "id": pid, "first": first, "last": last, "gender": gender,
            "birthdate": birthdate.isoformat(), "deathdate": deathdate,
            "race": race, "ethnicity": ethnicity, "marital": marital,
            "city": city, "state": state, "zip": zipcode,
            "age": age,
        }

        # CSV row
        self.patients_rows.append({
            "Id": pid, "BIRTHDATE": birthdate.isoformat(),
            "DEATHDATE": deathdate, "SSN": f"999-{random.randint(10,99)}-{random.randint(1000,9999)}",
            "FIRST": first, "LAST": last, "GENDER": gender,
            "RACE": race, "ETHNICITY": ethnicity, "MARITAL": marital,
            "CITY": city, "STATE": state, "ZIP": zipcode,
        })

        # Generate clinical data
        conditions = self._generate_conditions(patient)
        encounters = self._generate_encounters(patient, conditions)
        medications = self._generate_medications(patient, conditions)
        observations = self._generate_observations(patient, conditions, encounters)
        careplans = self._generate_careplans(patient, conditions)
        procedures = self._generate_procedures(patient, encounters)

        # Generate clinical notes for each significant encounter
        for enc in encounters:
            enc_conditions = [c for c in conditions if c["start"] <= enc["start"]]
            enc_meds = [m for m in medications if m["start"] <= enc["start"]]
            enc_obs = [o for o in observations if o["date"] == enc["start"][:10]]

            note_text = generate_clinical_note(patient, enc_conditions, enc_meds, enc, enc_obs)
            self.clinical_notes.append({
                "text": note_text,
                "patient_id": pid,
                "patient_name": f"{first} {last}",
                "encounter_id": enc["id"],
                "encounter_type": enc["type_display"],
                "encounter_date": enc["start"][:10],
                "note_type": "clinical_note",
                "conditions": [c["display"] for c in enc_conditions],
                "medications": [m["display"] for m in enc_meds],
            })

        patient["conditions"] = conditions
        patient["medications"] = medications
        patient["encounters"] = encounters
        patient["observations"] = observations
        patient["careplans"] = careplans
        patient["procedures"] = procedures

        return patient

    def _generate_conditions(self, patient: dict) -> list[dict]:
        """Assign conditions appropriate to patient demographics."""
        age = patient["age"]
        conditions = []

        # Determine number of chronic conditions based on age
        if age < 30:
            num_chronic = random.choices([0, 1], weights=[0.8, 0.2])[0]
        elif age < 50:
            num_chronic = random.choices([0, 1, 2], weights=[0.3, 0.5, 0.2])[0]
        elif age < 70:
            num_chronic = random.choices([1, 2, 3, 4], weights=[0.2, 0.35, 0.3, 0.15])[0]
        else:
            num_chronic = random.choices([2, 3, 4, 5], weights=[0.15, 0.35, 0.35, 0.15])[0]

        # Select chronic conditions appropriate for age
        eligible = [c for c in CHRONIC_CONDITIONS if c["onset_age_min"] <= age <= c["onset_age_max"]]
        selected = random.sample(eligible, min(num_chronic, len(eligible)))

        # If patient has diabetes + CKD, ensure realistic progression
        has_diabetes = any(c["code"] in ("44054006", "73211009") for c in selected)
        ckd_stages = [c for c in selected if c["code"].startswith("431") or c["code"] == "433144002"]
        if has_diabetes and not ckd_stages and age > 55 and random.random() < 0.4:
            # Add CKD as diabetic complication
            ckd_options = [c for c in CONDITIONS if c["code"] in ("431856006", "433144002", "431857002")]
            if ckd_options:
                selected.append(random.choice(ckd_options))

        # Add 1-2 acute conditions
        num_acute = random.randint(0, 2)
        acute_eligible = [c for c in CONDITIONS if c not in CHRONIC_CONDITIONS and c["onset_age_min"] <= age]
        selected += random.sample(acute_eligible, min(num_acute, len(acute_eligible)))

        for cond in selected:
            onset_years_ago = random.randint(0, min(age - cond["onset_age_min"], 20))
            onset_date = date.today() - timedelta(days=onset_years_ago * 365 + random.randint(0, 364))
            cid = str(uuid.uuid4())

            cond_record = {
                "id": cid, "code": cond["code"], "display": cond["display"],
                "system": cond["system"], "start": onset_date.isoformat(),
                "stop": "" if cond in CHRONIC_CONDITIONS else (onset_date + timedelta(days=random.randint(7, 90))).isoformat(),
            }
            conditions.append(cond_record)

            self.conditions_rows.append({
                "START": cond_record["start"], "STOP": cond_record["stop"],
                "PATIENT": patient["id"], "ENCOUNTER": "",
                "CODE": cond["code"], "DESCRIPTION": cond["display"],
            })

        return conditions

    def _generate_encounters(self, patient: dict, conditions: list) -> list[dict]:
        """Generate encounters (visits) for the patient."""
        encounters = []
        num_encounters = random.randint(3, 12)

        for _ in range(num_encounters):
            eid = str(uuid.uuid4())
            days_ago = random.randint(1, 365 * 3)
            start_dt = datetime.now(timezone.utc) - timedelta(days=days_ago)
            enc_type = random.choices(
                ENCOUNTER_TYPES[:4],
                weights=[0.5, 0.25, 0.1, 0.15],
            )[0]

            if enc_type["class"] == "inpatient":
                end_dt = start_dt + timedelta(days=random.randint(1, 14))
            elif enc_type["class"] == "emergency":
                end_dt = start_dt + timedelta(hours=random.randint(2, 12))
            else:
                end_dt = start_dt + timedelta(minutes=random.randint(15, 60))

            encounter = {
                "id": eid, "type_code": enc_type["code"],
                "type_display": enc_type["display"], "class": enc_type["class"],
                "start": start_dt.isoformat(), "end": end_dt.isoformat(),
                "reason_code": conditions[0]["code"] if conditions else "",
                "reason_display": conditions[0]["display"] if conditions else "",
            }
            encounters.append(encounter)

            self.encounters_rows.append({
                "Id": eid, "START": start_dt.isoformat(), "STOP": end_dt.isoformat(),
                "PATIENT": patient["id"], "CODE": enc_type["code"],
                "DESCRIPTION": enc_type["display"], "ENCOUNTERCLASS": enc_type["class"],
                "REASONCODE": encounter["reason_code"],
                "REASONDESCRIPTION": encounter["reason_display"],
            })

        return sorted(encounters, key=lambda e: e["start"])

    def _generate_medications(self, patient: dict, conditions: list) -> list[dict]:
        """Prescribe medications appropriate to conditions."""
        meds = []
        cond_codes = {c["code"] for c in conditions}

        for med in MEDICATIONS:
            # Check if medication is indicated for any active condition
            if med["for_conditions"] and not cond_codes.intersection(med["for_conditions"]):
                continue
            if med["for_conditions"] and random.random() < 0.3:
                continue  # Not all indicated meds are prescribed

            mid = str(uuid.uuid4())
            start_days_ago = random.randint(30, 365 * 3)
            start_date = (date.today() - timedelta(days=start_days_ago)).isoformat()
            # Most chronic meds are ongoing
            is_active = random.random() < 0.8
            stop_date = "" if is_active else (date.today() - timedelta(days=random.randint(1, start_days_ago))).isoformat()

            med_record = {
                "id": mid, "code": med["code"], "display": med["display"],
                "system": med["system"], "start": start_date, "stop": stop_date,
                "base_cost": med["base_cost"],
            }
            meds.append(med_record)

            self.medications_rows.append({
                "START": start_date, "STOP": stop_date,
                "PATIENT": patient["id"], "ENCOUNTER": "",
                "CODE": med["code"], "DESCRIPTION": med["display"],
                "BASE_COST": med["base_cost"],
                "REASONCODE": list(cond_codes.intersection(med["for_conditions"]))[0] if cond_codes.intersection(med["for_conditions"]) else "",
                "REASONDESCRIPTION": "",
            })

        return meds

    def _generate_observations(self, patient: dict, conditions: list, encounters: list) -> list[dict]:
        """Generate lab values and vital signs for each encounter."""
        obs_list = []
        cond_codes = {c["code"] for c in conditions}

        for enc in encounters:
            enc_date = enc["start"][:10]

            # Vital signs for every encounter
            for vital in OBSERVATIONS_VITAL_SIGNS:
                oid = str(uuid.uuid4())
                low, high = vital["range"]
                value = round(random.uniform(low, high), 1)

                obs = {"id": oid, "code": vital["code"], "display": vital["display"],
                       "unit": vital["unit"], "value": value, "date": enc_date}
                obs_list.append(obs)

                self.observations_rows.append({
                    "DATE": enc_date, "PATIENT": patient["id"],
                    "ENCOUNTER": enc["id"], "CODE": vital["code"],
                    "DESCRIPTION": vital["display"], "VALUE": str(value),
                    "UNITS": vital["unit"], "TYPE": "numeric",
                })

            # Lab values — condition-dependent with realistic ranges
            for lab in OBSERVATIONS_LAB:
                # Only generate relevant labs
                should_generate = random.random() < 0.4  # baseline probability
                if lab["code"] == "4548-4" and ("44054006" in cond_codes or "73211009" in cond_codes):
                    should_generate = True
                if lab["code"] in ("2160-0", "33914-3") and any(c.startswith("431") or c == "433144002" for c in cond_codes):
                    should_generate = True
                if lab["code"] == "33762-6" and "84114007" in cond_codes:
                    should_generate = True

                if not should_generate:
                    continue

                oid = str(uuid.uuid4())
                low, high = lab["range"]
                value = round(random.uniform(low, high), 1)

                # Adjust values for conditions
                if lab["code"] == "4548-4":  # A1c
                    if "44054006" in cond_codes:
                        value = round(random.uniform(6.0, 11.5), 1)
                    else:
                        value = round(random.uniform(4.5, 5.8), 1)
                if lab["code"] == "33914-3":  # eGFR
                    if "431857002" in cond_codes:
                        value = round(random.uniform(15, 29), 0)
                    elif "433144002" in cond_codes:
                        value = round(random.uniform(30, 59), 0)
                    elif "431856006" in cond_codes:
                        value = round(random.uniform(60, 89), 0)
                if lab["code"] == "2160-0":  # Creatinine
                    if "431857002" in cond_codes:
                        value = round(random.uniform(2.0, 5.0), 1)
                    elif "433144002" in cond_codes:
                        value = round(random.uniform(1.5, 2.5), 1)
                if lab["code"] == "33762-6":  # NT-proBNP
                    if "84114007" in cond_codes:
                        value = round(random.uniform(500, 4500), 0)
                    else:
                        value = round(random.uniform(50, 300), 0)

                obs = {"id": oid, "code": lab["code"], "display": lab["display"],
                       "unit": lab["unit"], "value": value, "date": enc_date}
                obs_list.append(obs)

                self.observations_rows.append({
                    "DATE": enc_date, "PATIENT": patient["id"],
                    "ENCOUNTER": enc["id"], "CODE": lab["code"],
                    "DESCRIPTION": lab["display"], "VALUE": str(value),
                    "UNITS": lab["unit"], "TYPE": "numeric",
                })

        return obs_list

    def _generate_careplans(self, patient: dict, conditions: list) -> list[dict]:
        """Generate care plans tied to conditions."""
        plans = []
        cond_codes = {c["code"] for c in conditions}

        for cp in CARE_PLANS:
            if cond_codes.intersection(cp["for_conditions"]):
                cpid = str(uuid.uuid4())
                start = (date.today() - timedelta(days=random.randint(30, 365))).isoformat()

                plan = {
                    "id": cpid, "code": cp["code"], "display": cp["display"],
                    "start": start, "stop": "",
                    "activities": cp["activities"],
                    "reason_code": list(cond_codes.intersection(cp["for_conditions"]))[0],
                }
                plans.append(plan)

                self.careplans_rows.append({
                    "Id": cpid, "START": start, "STOP": "",
                    "PATIENT": patient["id"],
                    "CODE": cp["code"], "DESCRIPTION": cp["display"],
                    "REASONCODE": plan["reason_code"],
                    "REASONDESCRIPTION": "",
                })

        return plans

    def _generate_procedures(self, patient: dict, encounters: list) -> list[dict]:
        """Generate procedures for relevant encounters."""
        procs = []
        for enc in encounters:
            eligible = [p for p in PROCEDURES if p["for_encounter"] == enc["class"]]
            if eligible and random.random() < 0.5:
                proc = random.choice(eligible)
                prid = str(uuid.uuid4())

                proc_record = {
                    "id": prid, "code": proc["code"], "display": proc["display"],
                    "date": enc["start"][:10], "encounter_id": enc["id"],
                }
                procs.append(proc_record)

                self.procedures_rows.append({
                    "DATE": enc["start"][:10], "PATIENT": patient["id"],
                    "ENCOUNTER": enc["id"], "CODE": proc["code"],
                    "DESCRIPTION": proc["display"],
                })

        return procs

    def _patient_to_fhir_bundle(self, patient: dict) -> dict:
        """Convert patient data to a FHIR R4 Bundle (Synthea format)."""
        entries = []

        # Patient resource
        entries.append({
            "fullUrl": f"urn:uuid:{patient['id']}",
            "resource": {
                "resourceType": "Patient",
                "id": patient["id"],
                "name": [{"use": "official", "family": patient["last"],
                          "given": [patient["first"]]}],
                "gender": "male" if patient["gender"] == "M" else "female",
                "birthDate": patient["birthdate"],
                "deceasedDateTime": patient["deathdate"] or None,
                "address": [{
                    "city": patient["city"], "state": patient["state"],
                    "postalCode": patient["zip"], "country": "US",
                }],
                "extension": [
                    {"url": "http://hl7.org/fhir/us/core/StructureDefinition/us-core-race",
                     "valueString": patient["race"]},
                    {"url": "http://hl7.org/fhir/us/core/StructureDefinition/us-core-ethnicity",
                     "valueString": patient["ethnicity"]},
                ],
            },
        })

        # Condition resources
        for cond in patient.get("conditions", []):
            entries.append({
                "fullUrl": f"urn:uuid:{cond['id']}",
                "resource": {
                    "resourceType": "Condition",
                    "id": cond["id"],
                    "clinicalStatus": {"coding": [{"code": "active"}]},
                    "code": {"coding": [{"system": cond["system"], "code": cond["code"],
                                          "display": cond["display"]}]},
                    "subject": {"reference": f"urn:uuid:{patient['id']}"},
                    "onsetDateTime": cond["start"],
                    "abatementDateTime": cond["stop"] or None,
                },
            })

        # MedicationRequest resources
        for med in patient.get("medications", []):
            entries.append({
                "fullUrl": f"urn:uuid:{med['id']}",
                "resource": {
                    "resourceType": "MedicationRequest",
                    "id": med["id"],
                    "status": "active" if not med["stop"] else "stopped",
                    "medicationCodeableConcept": {
                        "coding": [{"system": med["system"], "code": med["code"],
                                     "display": med["display"]}],
                    },
                    "subject": {"reference": f"urn:uuid:{patient['id']}"},
                    "authoredOn": med["start"],
                },
            })

        # Encounter resources
        for enc in patient.get("encounters", []):
            entries.append({
                "fullUrl": f"urn:uuid:{enc['id']}",
                "resource": {
                    "resourceType": "Encounter",
                    "id": enc["id"],
                    "status": "finished",
                    "class": {"code": enc["class"]},
                    "type": [{"coding": [{"code": enc["type_code"],
                                           "display": enc["type_display"]}]}],
                    "subject": {"reference": f"urn:uuid:{patient['id']}"},
                    "period": {"start": enc["start"], "end": enc["end"]},
                    "reasonCode": [{"coding": [{"code": enc["reason_code"],
                                                  "display": enc["reason_display"]}]}] if enc["reason_code"] else [],
                },
            })

        # Observation resources
        for obs in patient.get("observations", []):
            entries.append({
                "fullUrl": f"urn:uuid:{obs['id']}",
                "resource": {
                    "resourceType": "Observation",
                    "id": obs["id"],
                    "status": "final",
                    "code": {"coding": [{"code": obs["code"], "display": obs["display"]}]},
                    "subject": {"reference": f"urn:uuid:{patient['id']}"},
                    "effectiveDateTime": obs["date"],
                    "valueQuantity": {"value": obs["value"], "unit": obs["unit"]},
                },
            })

        # CarePlan resources
        for cp in patient.get("careplans", []):
            entries.append({
                "fullUrl": f"urn:uuid:{cp['id']}",
                "resource": {
                    "resourceType": "CarePlan",
                    "id": cp["id"],
                    "status": "active",
                    "intent": "order",
                    "category": [{"coding": [{"code": cp["code"], "display": cp["display"]}]}],
                    "subject": {"reference": f"urn:uuid:{patient['id']}"},
                    "period": {"start": cp["start"]},
                    "activity": [
                        {"detail": {"description": act}} for act in cp["activities"]
                    ],
                },
            })

        return {
            "resourceType": "Bundle",
            "type": "collection",
            "entry": entries,
        }

    def _write_csv(self, filename: str, rows: list[dict]) -> None:
        """Write rows to a CSV file in Synthea format."""
        if not rows:
            return
        path = self.csv_dir / filename
        fieldnames = list(rows[0].keys())
        with path.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate Synthea-format synthetic data")
    parser.add_argument("--patients", type=int, default=50, help="Number of patients")
    parser.add_argument("--output", type=Path, default=Path("data/synthea"), help="Output directory")
    args = parser.parse_args()

    gen = SyntheaGenerator(args.output, args.patients)
    gen.generate_all()


if __name__ == "__main__":
    main()
