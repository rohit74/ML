#!/usr/bin/env python3
"""
Ingest all healthcare data into the vector store.

Supports:
  - Synthea FHIR R4 bundles
  - Synthea CSV exports
  - Synthea-generated clinical notes
  - Reference data (drug interactions, ICD-10, guidelines)

Usage:
    python scripts/ingest_data.py                    # all sources
    python scripts/ingest_data.py --synthea-only      # only Synthea data
    python scripts/ingest_data.py --reference-only    # only reference data
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.config import get_settings
from src.config.logging import setup_logging, get_logger
from src.ingestion.fhir_parser import FHIRBundleParser
from src.ingestion.synthea_csv_parser import SyntheaCSVParser
from src.models.schemas import DocumentChunk, SourceType
from src.tools.file_loader import FileLoader
from src.tools.vector_store import VectorStore

logger = get_logger(__name__)


def ingest_synthea_fhir(store: VectorStore, fhir_dir: Path) -> int:
    """Ingest Synthea FHIR R4 bundles."""
    parser = FHIRBundleParser()
    chunks = parser.parse_directory(fhir_dir)
    if chunks:
        count = store.ingest(chunks)
        logger.info("ingested_fhir_bundles", chunks=count)
        return count
    return 0


def ingest_synthea_csv(store: VectorStore, csv_dir: Path) -> int:
    """Ingest Synthea CSV exports."""
    parser = SyntheaCSVParser()
    chunks = parser.parse_directory(csv_dir)
    if chunks:
        count = store.ingest(chunks)
        logger.info("ingested_synthea_csv", chunks=count)
        return count
    return 0


def ingest_synthea_clinical_notes(store: VectorStore, notes_path: Path) -> int:
    """Ingest generated clinical notes from Synthea data."""
    if not notes_path.exists():
        return 0

    with notes_path.open() as f:
        data = json.load(f)

    documents = data.get("documents", [])
    chunks: list[DocumentChunk] = []

    for doc in documents:
        text = doc.pop("text", "")
        if not text:
            continue

        from src.tools.file_loader import _chunk_text
        segments = _chunk_text(text, chunk_size=400, overlap=50)

        for segment in segments:
            meta = {k: v for k, v in doc.items()
                    if isinstance(v, (str, int, float, bool))}
            chunks.append(
                DocumentChunk(
                    content=segment,
                    source_type=SourceType.CLINICAL_NOTE,
                    metadata=meta,
                )
            )

    if chunks:
        count = store.ingest(chunks)
        logger.info("ingested_clinical_notes", chunks=count)
        return count
    return 0


def ingest_reference_data(store: VectorStore, sample_dir: Path) -> int:
    """Ingest drug interactions, ICD-10 codes, and clinical guidelines."""
    loader = FileLoader()
    total = 0

    for filename, source_type in [
        ("drug_interactions.json", SourceType.DRUG_REFERENCE),
        ("icd10_codes.json", SourceType.ICD_CODE),
        ("clinical_guidelines.json", SourceType.GUIDELINE),
    ]:
        filepath = sample_dir / filename
        if filepath.exists():
            chunks = loader.load_file(filepath, source_type=source_type)
            count = store.ingest(chunks)
            total += count
            logger.info("ingested_reference", file=filename, chunks=count)

    return total


def main() -> None:
    parser = argparse.ArgumentParser(description="Ingest healthcare data")
    parser.add_argument("--synthea-only", action="store_true")
    parser.add_argument("--reference-only", action="store_true")
    parser.add_argument("--synthea-dir", type=Path, default=None)
    args = parser.parse_args()

    settings = get_settings()
    setup_logging(settings.log_level)

    store = VectorStore()
    total = 0

    synthea_dir = args.synthea_dir or (settings.project_root / "data" / "synthea")

    if not args.reference_only:
        print("=" * 60)
        print("INGESTING SYNTHEA DATA")
        print("=" * 60)

        fhir_dir = synthea_dir / "fhir"
        if fhir_dir.exists():
            count = ingest_synthea_fhir(store, fhir_dir)
            total += count
            print(f"  ✓ FHIR bundles:     {count:>5} chunks")

        csv_dir = synthea_dir / "csv"
        if csv_dir.exists() and any(csv_dir.glob("*.csv")):
            count = ingest_synthea_csv(store, csv_dir)
            total += count
            print(f"  ✓ CSV exports:      {count:>5} chunks")

        notes_path = synthea_dir / "clinical_notes_synthea.json"
        if notes_path.exists():
            count = ingest_synthea_clinical_notes(store, notes_path)
            total += count
            print(f"  ✓ Clinical notes:   {count:>5} chunks")

    if not args.synthea_only:
        print("\n" + "=" * 60)
        print("INGESTING REFERENCE DATA")
        print("=" * 60)

        count = ingest_reference_data(store, settings.sample_data_dir)
        total += count
        print(f"  ✓ Reference data:   {count:>5} chunks")

    print("\n" + "=" * 60)
    doc_count = store.collection.count()
    print(f"TOTAL INGESTED:  {total} chunks")
    print(f"COLLECTION SIZE: {doc_count} documents")
    print(f"COLLECTION:      {settings.chroma_collection}")
    print(f"PERSIST DIR:     {settings.chroma_persist_dir}")
    print("=" * 60)


if __name__ == "__main__":
    main()
