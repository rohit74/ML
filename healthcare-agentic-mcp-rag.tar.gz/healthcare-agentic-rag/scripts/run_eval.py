#!/usr/bin/env python3
"""
Run the evaluation suite against the sample dataset.

Usage:
    python scripts/run_eval.py
    python scripts/run_eval.py --dataset data/sample/eval_queries.json
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.config import get_settings
from src.config.logging import setup_logging, get_logger
from src.evaluation.evaluator import Evaluator
from src.tools.vector_store import VectorStore

logger = get_logger(__name__)


async def main(dataset_path: Path) -> None:
    settings = get_settings()
    setup_logging(settings.log_level)

    # Ensure vector store has data
    store = VectorStore()
    store.rebuild_bm25_from_collection()
    doc_count = store.collection.count()

    if doc_count == 0:
        print("⚠  Vector store is empty. Run `python scripts/ingest_data.py` first.")
        sys.exit(1)

    print(f"📊 Running evaluation on {dataset_path}")
    print(f"   Vector store: {doc_count} documents")
    print()

    evaluator = Evaluator(vector_store=store)
    summary = await evaluator.evaluate_dataset(dataset_path)

    # Print results
    print("=" * 70)
    print("EVALUATION RESULTS")
    print("=" * 70)

    for i, result in enumerate(summary.results, 1):
        status = "✓" if result.passed else "✗"
        print(f"\n{status} [{i}] {result.query[:80]}")
        print(f"    Coverage: {result.topic_coverage:.0%} | "
              f"Confidence: {result.confidence:.2f} | "
              f"Faithfulness: {result.faithfulness_score:.2f} | "
              f"Citations: {result.citation_count} | "
              f"Latency: {result.latency_s:.1f}s")
        if result.topics_missing:
            print(f"    Missing: {', '.join(result.topics_missing)}")

    print("\n" + "=" * 70)
    print("AGGREGATE METRICS")
    print("=" * 70)
    metrics = summary.to_dict()
    for key, value in metrics.items():
        print(f"  {key:.<30} {value}")

    # Save to file
    output_path = settings.project_root / "data" / "eval_results.json"
    with output_path.open("w") as f:
        json.dump(metrics, f, indent=2)
    print(f"\n📄 Results saved to {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run Agentic RAG evaluation")
    parser.add_argument(
        "--dataset",
        type=Path,
        default=Path("data/sample/eval_queries.json"),
        help="Path to evaluation dataset JSON",
    )
    args = parser.parse_args()
    asyncio.run(main(args.dataset))
