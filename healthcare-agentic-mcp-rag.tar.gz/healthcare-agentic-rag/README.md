# Healthcare Agentic RAG with MCP

> Multi-agent Retrieval-Augmented Generation system for clinical decision support, built with LangGraph, LangChain, and Model Context Protocol (MCP). Uses **Synthea-generated synthetic patient data** to test agentic orchestration against real healthcare workflows: patient records, clinical notes, medications, diagnoses, observations, and care plans.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        FastAPI Gateway                          │
│                     POST /query, /ingest                        │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                   OrchestratorAgent (Planner)                   │
│  • Decomposes query into execution plan                        │
│  • Delegates to specialized agents via LangGraph               │
│  • Evaluates intermediate outputs; re-plans on failure         │
└────┬──────────┬──────────────────┬──────────────┬──────────────┘
     │          │                  │              │
     ▼          ▼                  ▼              ▼
┌─────────┐ ┌──────────────┐ ┌───────────┐ ┌────────────┐
│Retrieval│ │ToolSelection │ │ Synthesis  │ │ Validation │
│  Agent  │ │    Agent     │ │   Agent    │ │   Agent    │
│         │ │              │ │            │ │            │
│• Vector │ │• Route to    │ │• Fuse multi│ │• Fact-check│
│  search │ │  optimal tool│ │  source    │ │  against   │
│• BM25   │ │• Fallback    │ │  evidence  │ │  sources   │
│• Hybrid │ │  logic       │ │• Citation  │ │• Hallucin. │
│  rerank │ │• MCP bridge  │ │  grounding │ │  detection │
└─────────┘ └──────────────┘ └───────────┘ └────────────┘
     │              │                │              │
     ▼              ▼                ▼              ▼
┌─────────────────────────────────────────────────────────────────┐
│                         Tool Layer                              │
│  ChromaDB │ FileLoader │ ClinicalAPI │ MCP Server (drug/ICD)   │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Synthea Data Layer                            │
│  FHIR R4 Bundles │ CSV Exports │ Clinical Notes │ Ref Data     │
│  50 patients │ 132 conditions │ 227 medications │ 3817 obs     │
│  361 encounters │ 93 care plans │ 169 procedures               │
└─────────────────────────────────────────────────────────────────┘
```

## Five-Agent Design

| Agent | Responsibility | Tools | Design Rationale |
|-------|---------------|-------|------------------|
| **Orchestrator** | Query decomposition, execution planning, re-planning | LangGraph state management | Central planner that NEVER answers directly — only plans, delegates, evaluates |
| **Retrieval** | Hybrid search (vector + BM25), cross-encoder reranking | ChromaDB, BM25, SentenceTransformers | Exclusive ownership of VectorStore; other agents access chunks only through shared state |
| **Tool Selection** | Dynamic tool routing, MCP bridge, fallback chains | MCP Server, ClinicalAPI | Bridge between LLM reasoning and structured clinical tools; routes autonomously |
| **Synthesis** | Multi-source fusion, citation grounding, response generation | LLM chain | The ONLY agent that generates user-facing answers; all claims cite source chunks |
| **Validation** | Hallucination detection, source faithfulness scoring | Entailment scoring | Quality gate — triggers re-planning if faithfulness < threshold |

### Agent Creation Rationale

Agents were created based on **task decomposition**: when a sub-task required specialized reasoning or dedicated tool access (vector DB vs. file loader vs. external API), it got its own agent with a scoped system prompt and toolset. This follows LangGraph's node-based orchestration principle — each node owns a capability and the graph manages flow.

### Orchestration Flow

1. **Orchestrator** receives query → decomposes into execution plan → delegates
2. **Retrieval Agent** runs query expansion → hybrid search → cross-encoder reranking
3. **Tool Selection Agent** analyzes query → selects clinical tools → executes via MCP
4. **Synthesis Agent** fuses all evidence → generates cited answer → confidence score
5. **Validation Agent** fact-checks against sources → faithfulness score → pass/re-plan

Tool selection, sequencing, and fallback logic are **fully autonomous and not hardcoded**. The orchestrator's LLM-generated plan determines which agents run and in what order.

## Synthea Data Pipeline

### Why Synthea?

Synthea generates realistic synthetic patient records that mirror real EHR data structures. This project uses Synthea-format data to validate that the agentic architecture handles **production-scale healthcare workflows**, not toy examples:

- **Patient records** with demographics, conditions, medications, observations
- **FHIR R4 Bundles** — one per patient, containing all linked resources
- **CSV exports** — matching Synthea's standard export schema
- **Clinical notes** — generated from patient data with condition-specific narratives
- **Cross-resource linking** — conditions ↔ medications ↔ encounters ↔ observations ↔ care plans

### Data Pipeline

```
┌──────────────────────┐     ┌──────────────────────┐
│  generate_synthea    │     │  Real Synthea Output  │
│  _data.py (50 pts)   │     │  (drop-in compatible) │
└──────────┬───────────┘     └──────────┬───────────┘
           │                            │
           ▼                            ▼
    ┌──────────────┐            ┌──────────────┐
    │  FHIR R4     │            │  CSV Exports │
    │  Bundles     │            │  (7 tables)  │
    └──────┬───────┘            └──────┬───────┘
           │                           │
           ▼                           ▼
    ┌──────────────┐            ┌──────────────┐
    │  FHIR Bundle │            │  Synthea CSV │
    │  Parser      │            │  Parser      │
    └──────┬───────┘            └──────┬───────┘
           │                           │
           └─────────┬─────────────────┘
                     ▼
              ┌──────────────┐
              │ DocumentChunk│  (unified schema)
              │ + VectorStore│
              └──────────────┘
```

### Generated Data Statistics

| Resource | Count | Ingested Chunks |
|----------|-------|-----------------|
| Patients | 50 | 50 summaries |
| Conditions | 132 | 132 diagnosis chunks |
| Medications | 227 | 50 medication lists |
| Encounters | 361 | 361 encounter chunks |
| Observations | 3,817 | ~358 grouped observation chunks |
| Care Plans | 93 | 93 care plan chunks |
| Procedures | 169 | 169 procedure chunks |
| Clinical Notes | 361 | ~400+ chunked note segments |
| Drug Interactions | 12 | 12 reference chunks |
| ICD-10 Codes | 30 | 30 reference chunks |
| Clinical Guidelines | 8 | 8 guideline chunks |

### Swappable Data Sources

The ingestion pipeline is designed to work with **real Synthea output**. To use actual Synthea-generated data:

```bash
# Generate with Synthea
java -jar synthea-with-dependencies.jar -p 1000

# Point the ingestion at Synthea's output
python scripts/ingest_data.py --synthea-dir /path/to/synthea/output/fhir
```

## Quick Start

```bash
# 1. Clone and install
git clone https://github.com/<you>/healthcare-agentic-rag.git
cd healthcare-agentic-rag
pip install -e ".[dev]"

# 2. Configure
cp .env.example .env
# Set ANTHROPIC_API_KEY or OPENAI_API_KEY

# 3. Generate Synthea data (or point at real Synthea output)
python scripts/generate_synthea_data.py --patients 50

# 4. Ingest all data
python scripts/ingest_data.py

# 5. Run the API server
python -m src.api.server

# 6. Query
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "Find patients with diabetes and CKD stage 3+ who are on metformin. Should it be continued?"}'
```

## Example Queries (Testing Agentic Orchestration)

These queries exercise the full 5-agent pipeline across Synthea patient workflows:

```
# Cross-condition comorbidity analysis (retrieval + tool_selection + synthesis + validation)
"Which patients have both heart failure and CKD? What drug interaction concerns exist?"

# Clinical safety audit (full pipeline with re-planning)
"Are there patients with diabetes and CKD stage 3+ still prescribed metformin? Flag safety concerns."

# Population GDMT audit (hardest orchestration test)
"Are all heart failure patients receiving guideline-directed therapy with all four pillars?"

# Longitudinal observation analysis (temporal reasoning)
"Show eGFR and creatinine trends for CKD patients. Who is declining rapidly?"

# Care plan gap analysis (joins care plans + conditions + labs)
"What care plans exist for diabetic patients? Who has A1c > 8% needing intensification?"
```

## Evaluation

```bash
python scripts/run_eval.py --dataset data/sample/eval_queries.json
```

12 evaluation queries testing:
- Multi-source clinical decisions
- Cross-condition comorbidity analysis
- Medication-guideline concordance
- Care plan gap analysis
- Population-level analytics
- Longitudinal observation analysis
- Clinical safety audits
- Cross-resource linking (procedures ↔ encounters ↔ conditions)

Metrics: topic coverage, faithfulness, citation precision, confidence, latency p50/p99.

## Project Structure

```
healthcare-agentic-rag/
├── src/
│   ├── agents/
│   │   ├── orchestrator.py      # Query planning, delegation, re-planning
│   │   ├── retrieval.py         # Hybrid search + reranking
│   │   ├── tool_selection.py    # Dynamic MCP tool routing
│   │   ├── synthesis.py         # Evidence fusion + citation grounding
│   │   └── validation.py        # Hallucination detection
│   ├── graph/
│   │   └── workflow.py          # LangGraph directed graph with conditional edges
│   ├── tools/
│   │   ├── vector_store.py      # ChromaDB + BM25 + RRF + cross-encoder
│   │   ├── clinical_api.py      # Drug interactions, ICD-10, guidelines
│   │   ├── mcp_server.py        # MCP JSON-RPC server + client
│   │   ├── file_loader.py       # Multi-format document loader
│   │   └── llm_factory.py       # Configurable LLM backend
│   ├── ingestion/
│   │   ├── fhir_parser.py       # Synthea FHIR R4 bundle parser
│   │   └── synthea_csv_parser.py # Synthea CSV export parser
│   ├── evaluation/
│   │   └── evaluator.py         # Metrics framework
│   ├── api/
│   │   └── server.py            # FastAPI gateway
│   ├── config/
│   │   ├── __init__.py          # Pydantic settings
│   │   └── logging.py           # Structured logging
│   └── models/
│       └── schemas.py           # All Pydantic models + LangGraph state
├── data/
│   ├── synthea/
│   │   ├── fhir/                # FHIR R4 Bundle JSONs (1 per patient)
│   │   ├── csv/                 # Synthea CSV exports (7 tables)
│   │   └── clinical_notes_synthea.json
│   └── sample/                  # Reference data (drugs, ICD, guidelines)
├── scripts/
│   ├── generate_synthea_data.py # Synthea-format data generator
│   ├── ingest_data.py           # Multi-source ingestion pipeline
│   └── run_eval.py              # Evaluation runner
├── tests/
│   ├── test_core.py             # Schema, loader, API, agent unit tests
│   └── test_synthea_ingestion.py # FHIR + CSV parser tests (16 tests)
├── Dockerfile
├── docker-compose.yml
├── pyproject.toml
└── .env.example
```

## Tech Stack

- **Orchestration**: LangGraph, LangChain
- **Vector Store**: ChromaDB (swappable to Pinecone/Weaviate)
- **Retrieval**: Hybrid (dense + BM25 + RRF), cross-encoder reranking
- **Embeddings**: `all-MiniLM-L6-v2` (local) or `text-embedding-3-small` (OpenAI)
- **LLM**: Claude 3.5 Sonnet / GPT-4o (configurable)
- **MCP**: Model Context Protocol server for structured clinical tools
- **Data**: Synthea FHIR R4 + CSV + generated clinical notes
- **API**: FastAPI with async support
- **Observability**: LangSmith tracing, structlog

## Docker

```bash
docker compose up --build
```

## Tests

```bash
# Unit tests (no LLM/API keys needed for ingestion tests)
pytest tests/ -v

# With full LangChain stack
pip install -e ".[dev]"
pytest tests/ -v
```

## License

MIT
