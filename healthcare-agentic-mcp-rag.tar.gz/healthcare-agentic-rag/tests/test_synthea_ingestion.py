"""
Tests for Synthea data ingestion — FHIR bundle parser and CSV parser.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest

from src.ingestion.fhir_parser import FHIRBundleParser
from src.ingestion.synthea_csv_parser import SyntheaCSVParser
from src.models.schemas import SourceType


# ═══════════════════════════════════════════════════════════════════════
#  FHIR Bundle Parser Tests
# ═══════════════════════════════════════════════════════════════════════


class TestFHIRBundleParser:
    """Test parsing of Synthea FHIR R4 bundles."""

    def _make_bundle(self, patient_id: str = "test-123") -> dict:
        """Create a minimal FHIR bundle for testing."""
        return {
            "resourceType": "Bundle",
            "type": "collection",
            "entry": [
                {
                    "fullUrl": f"urn:uuid:{patient_id}",
                    "resource": {
                        "resourceType": "Patient",
                        "id": patient_id,
                        "name": [{"use": "official", "family": "Smith", "given": ["John"]}],
                        "gender": "male",
                        "birthDate": "1960-05-15",
                        "address": [{"city": "Boston", "state": "MA"}],
                    },
                },
                {
                    "fullUrl": "urn:uuid:cond-001",
                    "resource": {
                        "resourceType": "Condition",
                        "id": "cond-001",
                        "clinicalStatus": {"coding": [{"code": "active"}]},
                        "code": {
                            "coding": [{"system": "http://snomed.info/sct",
                                         "code": "44054006",
                                         "display": "Diabetes mellitus type 2"}]
                        },
                        "subject": {"reference": f"urn:uuid:{patient_id}"},
                        "onsetDateTime": "2015-03-10",
                    },
                },
                {
                    "fullUrl": "urn:uuid:med-001",
                    "resource": {
                        "resourceType": "MedicationRequest",
                        "id": "med-001",
                        "status": "active",
                        "medicationCodeableConcept": {
                            "coding": [{"system": "http://www.nlm.nih.gov/research/umls/rxnorm",
                                         "code": "860975",
                                         "display": "Metformin 500 MG Oral Tablet"}]
                        },
                        "subject": {"reference": f"urn:uuid:{patient_id}"},
                        "authoredOn": "2015-03-10",
                    },
                },
                {
                    "fullUrl": "urn:uuid:enc-001",
                    "resource": {
                        "resourceType": "Encounter",
                        "id": "enc-001",
                        "status": "finished",
                        "class": {"code": "ambulatory"},
                        "type": [{"coding": [{"code": "185345009",
                                               "display": "Encounter for check up"}]}],
                        "subject": {"reference": f"urn:uuid:{patient_id}"},
                        "period": {"start": "2024-01-15T09:00:00Z", "end": "2024-01-15T09:30:00Z"},
                    },
                },
                {
                    "fullUrl": "urn:uuid:obs-001",
                    "resource": {
                        "resourceType": "Observation",
                        "id": "obs-001",
                        "status": "final",
                        "code": {"coding": [{"code": "4548-4", "display": "Hemoglobin A1c"}]},
                        "subject": {"reference": f"urn:uuid:{patient_id}"},
                        "effectiveDateTime": "2024-01-15",
                        "valueQuantity": {"value": 7.8, "unit": "%"},
                    },
                },
                {
                    "fullUrl": "urn:uuid:cp-001",
                    "resource": {
                        "resourceType": "CarePlan",
                        "id": "cp-001",
                        "status": "active",
                        "intent": "order",
                        "category": [{"coding": [{"code": "698360004",
                                                    "display": "Diabetes self management plan"}]}],
                        "subject": {"reference": f"urn:uuid:{patient_id}"},
                        "period": {"start": "2015-03-10"},
                        "activity": [
                            {"detail": {"description": "Diabetic diet"}},
                            {"detail": {"description": "Blood glucose monitoring"}},
                        ],
                    },
                },
            ],
        }

    def test_parse_bundle_basic(self, tmp_path: Path):
        """Test parsing a complete FHIR bundle."""
        bundle = self._make_bundle()
        bundle_path = tmp_path / "test-patient.json"
        bundle_path.write_text(json.dumps(bundle))

        parser = FHIRBundleParser()
        chunks = parser.parse_bundle(bundle_path)

        assert len(chunks) > 0
        # Should have: patient summary + condition + medication summary + encounter + observations + careplan
        chunk_types = {c.metadata.get("chunk_type") for c in chunks}
        assert "patient_summary" in chunk_types
        assert "condition" in chunk_types
        assert "medication_list" in chunk_types

    def test_parse_bundle_patient_name(self, tmp_path: Path):
        """Test patient name extraction."""
        bundle = self._make_bundle()
        bundle_path = tmp_path / "test-patient.json"
        bundle_path.write_text(json.dumps(bundle))

        parser = FHIRBundleParser()
        chunks = parser.parse_bundle(bundle_path)

        summary = next(c for c in chunks if c.metadata.get("chunk_type") == "patient_summary")
        assert "John Smith" in summary.content

    def test_parse_bundle_condition(self, tmp_path: Path):
        """Test condition extraction."""
        bundle = self._make_bundle()
        bundle_path = tmp_path / "test-patient.json"
        bundle_path.write_text(json.dumps(bundle))

        parser = FHIRBundleParser()
        chunks = parser.parse_bundle(bundle_path)

        condition_chunks = [c for c in chunks if c.metadata.get("chunk_type") == "condition"]
        assert len(condition_chunks) == 1
        assert "Diabetes mellitus type 2" in condition_chunks[0].content
        assert condition_chunks[0].metadata["condition_code"] == "44054006"

    def test_parse_bundle_medications(self, tmp_path: Path):
        """Test medication list extraction."""
        bundle = self._make_bundle()
        bundle_path = tmp_path / "test-patient.json"
        bundle_path.write_text(json.dumps(bundle))

        parser = FHIRBundleParser()
        chunks = parser.parse_bundle(bundle_path)

        med_chunks = [c for c in chunks if c.metadata.get("chunk_type") == "medication_list"]
        assert len(med_chunks) == 1
        assert "Metformin 500 MG" in med_chunks[0].content

    def test_parse_bundle_observations(self, tmp_path: Path):
        """Test observation extraction."""
        bundle = self._make_bundle()
        bundle_path = tmp_path / "test-patient.json"
        bundle_path.write_text(json.dumps(bundle))

        parser = FHIRBundleParser()
        chunks = parser.parse_bundle(bundle_path)

        obs_chunks = [c for c in chunks if c.metadata.get("chunk_type") == "observations"]
        assert len(obs_chunks) >= 1
        assert any("Hemoglobin A1c" in c.content and "7.8" in c.content for c in obs_chunks)

    def test_parse_bundle_careplan(self, tmp_path: Path):
        """Test care plan extraction."""
        bundle = self._make_bundle()
        bundle_path = tmp_path / "test-patient.json"
        bundle_path.write_text(json.dumps(bundle))

        parser = FHIRBundleParser()
        chunks = parser.parse_bundle(bundle_path)

        cp_chunks = [c for c in chunks if c.metadata.get("chunk_type") == "careplan"]
        assert len(cp_chunks) == 1
        assert "Diabetes self management" in cp_chunks[0].content
        assert "Diabetic diet" in cp_chunks[0].content

    def test_parse_directory(self, tmp_path: Path):
        """Test parsing multiple bundles from a directory."""
        for i in range(3):
            bundle = self._make_bundle(f"patient-{i}")
            (tmp_path / f"patient-{i}.json").write_text(json.dumps(bundle))

        parser = FHIRBundleParser()
        chunks = parser.parse_directory(tmp_path)

        assert len(chunks) > 3  # Multiple chunks per patient
        patient_ids = {c.metadata["patient_id"] for c in chunks}
        assert len(patient_ids) == 3

    def test_parse_non_bundle(self, tmp_path: Path):
        """Test graceful handling of non-Bundle JSON."""
        (tmp_path / "not-bundle.json").write_text('{"resourceType": "Patient"}')
        parser = FHIRBundleParser()
        chunks = parser.parse_bundle(tmp_path / "not-bundle.json")
        assert chunks == []

    def test_source_type(self, tmp_path: Path):
        """Test all chunks have correct source type."""
        bundle = self._make_bundle()
        (tmp_path / "test.json").write_text(json.dumps(bundle))

        parser = FHIRBundleParser()
        chunks = parser.parse_bundle(tmp_path / "test.json")

        for chunk in chunks:
            assert chunk.source_type == SourceType.CLINICAL_NOTE


# ═══════════════════════════════════════════════════════════════════════
#  Synthea CSV Parser Tests
# ═══════════════════════════════════════════════════════════════════════


class TestSyntheaCSVParser:
    """Test parsing of Synthea CSV exports."""

    def _write_csv(self, path: Path, headers: list[str], rows: list[dict]) -> None:
        with path.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            writer.writerows(rows)

    def _setup_csvs(self, tmp_path: Path) -> None:
        """Create a minimal set of Synthea CSVs."""
        self._write_csv(
            tmp_path / "patients.csv",
            ["Id", "BIRTHDATE", "DEATHDATE", "SSN", "FIRST", "LAST", "GENDER",
             "RACE", "ETHNICITY", "MARITAL", "CITY", "STATE", "ZIP"],
            [{"Id": "pt-001", "BIRTHDATE": "1960-05-15", "DEATHDATE": "",
              "SSN": "999-12-3456", "FIRST": "Jane", "LAST": "Doe",
              "GENDER": "F", "RACE": "white", "ETHNICITY": "nonhispanic",
              "MARITAL": "M", "CITY": "Boston", "STATE": "MA", "ZIP": "02101"}],
        )

        self._write_csv(
            tmp_path / "conditions.csv",
            ["START", "STOP", "PATIENT", "ENCOUNTER", "CODE", "DESCRIPTION"],
            [
                {"START": "2018-01-10", "STOP": "", "PATIENT": "pt-001",
                 "ENCOUNTER": "enc-001", "CODE": "44054006",
                 "DESCRIPTION": "Diabetes mellitus type 2"},
                {"START": "2020-06-15", "STOP": "", "PATIENT": "pt-001",
                 "ENCOUNTER": "enc-002", "CODE": "38341003",
                 "DESCRIPTION": "Hypertensive disorder"},
            ],
        )

        self._write_csv(
            tmp_path / "medications.csv",
            ["START", "STOP", "PATIENT", "ENCOUNTER", "CODE", "DESCRIPTION",
             "BASE_COST", "REASONCODE", "REASONDESCRIPTION"],
            [
                {"START": "2018-01-10", "STOP": "", "PATIENT": "pt-001",
                 "ENCOUNTER": "enc-001", "CODE": "860975",
                 "DESCRIPTION": "Metformin 500 MG Oral Tablet",
                 "BASE_COST": "5.42", "REASONCODE": "44054006",
                 "REASONDESCRIPTION": "Diabetes mellitus type 2"},
                {"START": "2020-06-15", "STOP": "", "PATIENT": "pt-001",
                 "ENCOUNTER": "enc-002", "CODE": "316672",
                 "DESCRIPTION": "Lisinopril 10 MG Oral Tablet",
                 "BASE_COST": "3.20", "REASONCODE": "38341003",
                 "REASONDESCRIPTION": "Hypertensive disorder"},
            ],
        )

        self._write_csv(
            tmp_path / "encounters.csv",
            ["Id", "START", "STOP", "PATIENT", "CODE", "DESCRIPTION",
             "ENCOUNTERCLASS", "REASONCODE", "REASONDESCRIPTION"],
            [
                {"Id": "enc-001", "START": "2024-01-15T09:00:00Z",
                 "STOP": "2024-01-15T09:30:00Z", "PATIENT": "pt-001",
                 "CODE": "185345009", "DESCRIPTION": "Encounter for check up",
                 "ENCOUNTERCLASS": "ambulatory", "REASONCODE": "44054006",
                 "REASONDESCRIPTION": "Diabetes mellitus type 2"},
            ],
        )

        self._write_csv(
            tmp_path / "observations.csv",
            ["DATE", "PATIENT", "ENCOUNTER", "CODE", "DESCRIPTION",
             "VALUE", "UNITS", "TYPE"],
            [
                {"DATE": "2024-01-15", "PATIENT": "pt-001",
                 "ENCOUNTER": "enc-001", "CODE": "4548-4",
                 "DESCRIPTION": "Hemoglobin A1c", "VALUE": "8.2",
                 "UNITS": "%", "TYPE": "numeric"},
                {"DATE": "2024-01-15", "PATIENT": "pt-001",
                 "ENCOUNTER": "enc-001", "CODE": "33914-3",
                 "DESCRIPTION": "eGFR", "VALUE": "42",
                 "UNITS": "mL/min/{1.73_m2}", "TYPE": "numeric"},
            ],
        )

        self._write_csv(
            tmp_path / "careplans.csv",
            ["Id", "START", "STOP", "PATIENT", "CODE", "DESCRIPTION",
             "REASONCODE", "REASONDESCRIPTION"],
            [
                {"Id": "cp-001", "START": "2018-01-10", "STOP": "",
                 "PATIENT": "pt-001", "CODE": "698360004",
                 "DESCRIPTION": "Diabetes self management plan",
                 "REASONCODE": "44054006", "REASONDESCRIPTION": ""},
            ],
        )

        self._write_csv(
            tmp_path / "procedures.csv",
            ["DATE", "PATIENT", "ENCOUNTER", "CODE", "DESCRIPTION"],
            [
                {"DATE": "2024-01-15", "PATIENT": "pt-001",
                 "ENCOUNTER": "enc-001", "CODE": "430193006",
                 "DESCRIPTION": "Medication reconciliation"},
            ],
        )

    def test_parse_directory(self, tmp_path: Path):
        """Test full CSV directory parsing."""
        self._setup_csvs(tmp_path)
        parser = SyntheaCSVParser()
        chunks = parser.parse_directory(tmp_path)

        assert len(chunks) > 0
        chunk_types = {c.metadata.get("chunk_type") for c in chunks}
        assert "patient_summary" in chunk_types
        assert "condition" in chunk_types
        assert "medication_list" in chunk_types
        assert "encounter" in chunk_types
        assert "careplan" in chunk_types
        assert "procedure" in chunk_types

    def test_patient_summary_content(self, tmp_path: Path):
        """Test patient summary contains key information."""
        self._setup_csvs(tmp_path)
        parser = SyntheaCSVParser()
        chunks = parser.parse_directory(tmp_path)

        summary = next(c for c in chunks if c.metadata.get("chunk_type") == "patient_summary")
        assert "Jane Doe" in summary.content
        assert "Diabetes mellitus type 2" in summary.content
        assert "Metformin" in summary.content

    def test_condition_linking(self, tmp_path: Path):
        """Test conditions are linked to patient."""
        self._setup_csvs(tmp_path)
        parser = SyntheaCSVParser()
        chunks = parser.parse_directory(tmp_path)

        cond_chunks = [c for c in chunks if c.metadata.get("chunk_type") == "condition"]
        assert len(cond_chunks) == 2
        assert all(c.metadata["patient_name"] == "Jane Doe" for c in cond_chunks)

    def test_encounter_with_observations(self, tmp_path: Path):
        """Test encounters include linked observations."""
        self._setup_csvs(tmp_path)
        parser = SyntheaCSVParser()
        chunks = parser.parse_directory(tmp_path)

        enc_chunks = [c for c in chunks if c.metadata.get("chunk_type") == "encounter"]
        assert len(enc_chunks) >= 1
        # The encounter should have linked observations
        enc = enc_chunks[0]
        assert "Hemoglobin A1c" in enc.content or "eGFR" in enc.content

    def test_medication_list(self, tmp_path: Path):
        """Test medication list is comprehensive."""
        self._setup_csvs(tmp_path)
        parser = SyntheaCSVParser()
        chunks = parser.parse_directory(tmp_path)

        med_chunks = [c for c in chunks if c.metadata.get("chunk_type") == "medication_list"]
        assert len(med_chunks) == 1
        assert "Metformin" in med_chunks[0].content
        assert "Lisinopril" in med_chunks[0].content

    def test_empty_directory(self, tmp_path: Path):
        """Test handling of empty directory."""
        parser = SyntheaCSVParser()
        chunks = parser.parse_directory(tmp_path)
        assert chunks == []

    def test_missing_directory(self, tmp_path: Path):
        """Test handling of non-existent directory."""
        parser = SyntheaCSVParser()
        chunks = parser.parse_directory(tmp_path / "nonexistent")
        assert chunks == []
