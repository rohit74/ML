"""
Test suite for the Healthcare Agentic RAG system.

Covers:
  - Schema validation
  - File loader chunking
  - Clinical API lookups
  - Vector store operations
  - Orchestrator plan parsing
  - Synthesis citation extraction
  - Validation verdict parsing
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src.models.schemas import (
    AgentRole,
    AgentState,
    Citation,
    DocumentChunk,
    ExecutionPlan,
    PlanStep,
    PlanStepStatus,
    QueryRequest,
    QueryResponse,
    RetrievalResult,
    SourceType,
    SynthesisResult,
    ToolCall,
    ToolSelectionResult,
    ValidationVerdict,
)


# ═══════════════════════════════════════════════════════════════════════
#  Schema Tests
# ═══════════════════════════════════════════════════════════════════════


class TestSchemas:
    """Validate Pydantic model serialisation."""

    def test_document_chunk_creation(self):
        chunk = DocumentChunk(
            content="Patient has type 2 diabetes.",
            source_type=SourceType.CLINICAL_NOTE,
            metadata={"patient_id": "PT-001"},
            score=0.95,
        )
        assert chunk.source_type == SourceType.CLINICAL_NOTE
        assert chunk.score == 0.95
        assert "PT-001" in chunk.metadata["patient_id"]

    def test_document_chunk_serialisation(self):
        chunk = DocumentChunk(
            content="Test content",
            source_type=SourceType.DRUG_REFERENCE,
        )
        data = chunk.model_dump(mode="json")
        assert data["source_type"] == "drug_reference"
        restored = DocumentChunk(**data)
        assert restored.content == "Test content"

    def test_execution_plan(self):
        plan = ExecutionPlan(
            query="Test query",
            steps=[
                PlanStep(agent=AgentRole.RETRIEVAL, description="Search"),
                PlanStep(agent=AgentRole.SYNTHESIS, description="Synthesise"),
                PlanStep(agent=AgentRole.VALIDATION, description="Validate"),
            ],
        )
        assert len(plan.steps) == 3
        assert plan.steps[0].status == PlanStepStatus.PENDING

    def test_query_request_validation(self):
        req = QueryRequest(query="What is the treatment for diabetes?")
        assert len(req.session_id) > 0

        with pytest.raises(Exception):
            QueryRequest(query="ab")  # too short

    def test_synthesis_result(self):
        result = SynthesisResult(
            answer="Metformin is first-line [Source 0].",
            citations=[
                Citation(
                    chunk_id="abc123",
                    source_type=SourceType.GUIDELINE,
                    excerpt="Metformin remains...",
                )
            ],
            confidence=0.85,
        )
        assert result.confidence == 0.85
        assert len(result.citations) == 1

    def test_validation_verdict(self):
        verdict = ValidationVerdict(
            is_faithful=True,
            faithfulness_score=0.92,
            flagged_claims=[],
            reasoning="All claims supported.",
        )
        assert verdict.is_faithful
        assert verdict.faithfulness_score == 0.92


# ═══════════════════════════════════════════════════════════════════════
#  File Loader Tests
# ═══════════════════════════════════════════════════════════════════════


class TestFileLoader:
    """Test document loading and chunking."""

    def test_chunk_text_short(self):
        from src.tools.file_loader import _chunk_text

        text = "This is a short document."
        chunks = _chunk_text(text)
        assert len(chunks) == 1
        assert chunks[0] == text

    def test_chunk_text_long(self):
        from src.tools.file_loader import _chunk_text

        # Generate text longer than default chunk size
        words = ["word"] * 1000
        text = " ".join(words)
        chunks = _chunk_text(text, chunk_size=100, overlap=10)
        assert len(chunks) > 1
        # Each chunk (except possibly the last) should have ~100 words
        assert len(chunks[0].split()) == 100

    def test_load_json_file(self, tmp_path: Path):
        from src.tools.file_loader import FileLoader

        data = {"documents": [{"text": "Patient presented with chest pain."}]}
        json_file = tmp_path / "notes.json"
        json_file.write_text(json.dumps(data))

        loader = FileLoader()
        chunks = loader.load_file(json_file, SourceType.CLINICAL_NOTE)
        assert len(chunks) == 1
        assert "chest pain" in chunks[0].content

    def test_load_csv_file(self, tmp_path: Path):
        from src.tools.file_loader import FileLoader

        csv_content = "code,description\nE11.9,Type 2 diabetes\nI10,Hypertension\n"
        csv_file = tmp_path / "codes.csv"
        csv_file.write_text(csv_content)

        loader = FileLoader()
        chunks = loader.load_file(csv_file, SourceType.ICD_CODE)
        assert len(chunks) == 2

    def test_load_text_file(self, tmp_path: Path):
        from src.tools.file_loader import FileLoader

        txt_file = tmp_path / "note.txt"
        txt_file.write_text("Patient is a 55-year-old male with hypertension.")

        loader = FileLoader()
        chunks = loader.load_file(txt_file, SourceType.CLINICAL_NOTE)
        assert len(chunks) == 1


# ═══════════════════════════════════════════════════════════════════════
#  Clinical API Tests
# ═══════════════════════════════════════════════════════════════════════


class TestClinicalAPI:
    """Test clinical data lookups."""

    def test_drug_interaction_lookup(self, tmp_path: Path):
        from src.tools.clinical_api import ClinicalAPI

        # Create test data
        data = [
            {
                "drug_a": "Metformin",
                "drug_b": "Contrast Dye",
                "severity": "major",
                "description": "Risk of lactic acidosis",
                "management": "Hold metformin",
            }
        ]
        (tmp_path / "drug_interactions.json").write_text(json.dumps(data))

        api = ClinicalAPI()
        api._drug_data = data  # Inject test data

        results = api.lookup_drug_interactions("metformin")
        assert len(results) == 1
        assert results[0]["severity"] == "major"

    def test_icd_search(self):
        from src.tools.clinical_api import ClinicalAPI

        api = ClinicalAPI()
        api._icd_data = [
            {"code": "E11.9", "description": "Type 2 diabetes mellitus without complications"},
            {"code": "I10", "description": "Essential hypertension"},
        ]

        results = api.search_icd_codes("diabetes")
        assert len(results) == 1
        assert results[0]["code"] == "E11.9"

    def test_guideline_lookup(self):
        from src.tools.clinical_api import ClinicalAPI

        api = ClinicalAPI()
        api._guideline_data = [
            {
                "title": "ADA Standards",
                "condition": "type 2 diabetes",
                "content": "Metformin is first-line therapy.",
                "source": "ADA 2024",
            }
        ]

        results = api.get_guideline("diabetes")
        assert len(results) == 1
        assert "Metformin" in results[0]["content"]


# ═══════════════════════════════════════════════════════════════════════
#  Orchestrator Tests
# ═══════════════════════════════════════════════════════════════════════


class TestOrchestrator:
    """Test plan generation and step management."""

    def test_parse_plan_steps_valid_json(self):
        from src.agents.orchestrator import OrchestratorAgent

        raw = json.dumps([
            {"agent": "retrieval", "description": "Search knowledge base"},
            {"agent": "tool_selection", "description": "Look up drug interactions"},
            {"agent": "synthesis", "description": "Generate answer"},
            {"agent": "validation", "description": "Check faithfulness"},
        ])

        steps = OrchestratorAgent._parse_plan_steps(raw)
        assert len(steps) == 4
        assert steps[0].agent == AgentRole.RETRIEVAL
        assert steps[-1].agent == AgentRole.VALIDATION

    def test_parse_plan_steps_with_markdown_fences(self):
        from src.agents.orchestrator import OrchestratorAgent

        raw = '```json\n[{"agent": "retrieval", "description": "Search"}]\n```'
        steps = OrchestratorAgent._parse_plan_steps(raw)
        # Should include retrieval + auto-added synthesis + validation
        agents = {s.agent for s in steps}
        assert AgentRole.RETRIEVAL in agents
        assert AgentRole.SYNTHESIS in agents
        assert AgentRole.VALIDATION in agents

    def test_parse_plan_steps_fallback(self):
        from src.agents.orchestrator import OrchestratorAgent

        steps = OrchestratorAgent._parse_plan_steps("not valid json at all")
        # Fallback plan should have at least 3 steps
        assert len(steps) >= 3

    def test_advance_step(self):
        from src.agents.orchestrator import OrchestratorAgent

        orch = OrchestratorAgent()
        state: AgentState = {
            "query": "test",
            "plan": {
                "steps": [
                    {"agent": "retrieval", "description": "Step 1", "status": "pending",
                     "step_id": "a", "input_keys": [], "result": None, "error": None},
                    {"agent": "synthesis", "description": "Step 2", "status": "pending",
                     "step_id": "b", "input_keys": [], "result": None, "error": None},
                ]
            },
            "current_step_index": 0,
        }

        state = orch.advance_step(state)
        assert state["current_step_index"] == 1
        assert state["plan"]["steps"][0]["status"] == "completed"


# ═══════════════════════════════════════════════════════════════════════
#  Synthesis Tests
# ═══════════════════════════════════════════════════════════════════════


class TestSynthesis:
    """Test synthesis response parsing."""

    def test_parse_response(self):
        from src.agents.synthesis import SynthesisAgent

        raw = "ANSWER:\nMetformin is contraindicated [Source 0].\n\nCONFIDENCE: 0.85"
        answer, confidence = SynthesisAgent._parse_response(raw)
        assert "Metformin" in answer
        assert confidence == 0.85

    def test_parse_response_no_confidence(self):
        from src.agents.synthesis import SynthesisAgent

        raw = "ANSWER:\nSome answer without confidence."
        answer, confidence = SynthesisAgent._parse_response(raw)
        assert "Some answer" in answer
        assert confidence == 0.5  # default

    def test_extract_citations(self):
        from src.agents.synthesis import SynthesisAgent

        chunks = [
            DocumentChunk(content="Source A content", source_type=SourceType.GUIDELINE, chunk_id="aaa"),
            DocumentChunk(content="Source B content", source_type=SourceType.DRUG_REFERENCE, chunk_id="bbb"),
        ]
        answer = "Metformin is first-line [Source 0]. It has interactions [Source 1]."

        citations = SynthesisAgent._extract_citations(answer, chunks)
        assert len(citations) == 2
        assert citations[0].chunk_id == "aaa"
        assert citations[1].chunk_id == "bbb"


# ═══════════════════════════════════════════════════════════════════════
#  Validation Tests
# ═══════════════════════════════════════════════════════════════════════


class TestValidation:
    """Test validation verdict parsing."""

    def test_parse_verdict_valid_json(self):
        from src.agents.validation import ValidationAgent

        raw = json.dumps({
            "is_faithful": True,
            "faithfulness_score": 0.92,
            "flagged_claims": [],
            "reasoning": "All claims are well-supported.",
        })

        verdict = ValidationAgent._parse_verdict(raw)
        assert verdict.is_faithful
        assert verdict.faithfulness_score == 0.92

    def test_parse_verdict_with_fences(self):
        from src.agents.validation import ValidationAgent

        raw = '```json\n{"is_faithful": false, "faithfulness_score": 0.3, "flagged_claims": ["Unsupported claim"], "reasoning": "Low support"}\n```'

        verdict = ValidationAgent._parse_verdict(raw)
        assert not verdict.is_faithful
        assert len(verdict.flagged_claims) == 1

    def test_parse_verdict_fallback(self):
        from src.agents.validation import ValidationAgent

        verdict = ValidationAgent._parse_verdict("invalid json response")
        # Should return fallback with marginal pass
        assert verdict.faithfulness_score == 0.6
